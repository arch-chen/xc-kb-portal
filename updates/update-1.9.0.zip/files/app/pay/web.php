<?php
declare(strict_types=1);

/**
 * 支付相关控制器（1.9.0）：发起支付 / 异步通知 / 同步回跳 / 后台配置
 */

/**
 * 发起支付。
 * POST：plan_id + method（新单）或 order_id + method（继续付已存在的待支付单）
 * 成功后 302 到平台，或渲染一张自动提交到收银台的表单。
 */
function ctrl_pay_go(): void
{
    $u = require_login();
    $uid = (int)$u['id'];

    if (!is_post()) {
        redirect(u('recharge'));
    }
    csrf_check();

    $method = (string)post('method', '');
    $orderId = (int)post('order_id', '0');
    $o = null;

    try {
        if ($orderId > 0) {
            $o = pay_order_get($orderId);
            if (!$o || (int)$o['user_id'] !== $uid) {
                throw new PayError('forbidden', '订单不存在或不属于你');
            }
            if ($method === '') {
                $method = (string)($o['pay_method'] ?? '');
            }
        } else {
            $orderId = pay_order_new($uid, (int)post('plan_id', '0'), $method);
            $o = pay_order_get($orderId);
        }
        if ($method === '') {
            $methods = pay_methods();
            $method = (string)(array_key_first($methods) ?: 'alipay');
        }
        $r = pay_start($orderId, $method, client_ip(), (string)($_SERVER['HTTP_USER_AGENT'] ?? ''));
    } catch (PayError $e) {
        flash($e->getMessage(), 'err');
        redirect(u('recharge'));
    } catch (Throwable $e) {
        flash('发起支付失败：' . $e->getMessage(), 'err');
        redirect(u('recharge'));
    }

    if ((string)$r['mode'] === 'jump' && (string)($r['url'] ?? '') !== '') {
        header('Location: ' . (string)$r['url']);
        exit;
    }

    // form / qrcode：渲染跳转页。qrcode 模式下平台收银台自己会画二维码，这里仍走 form。
    view('pay_go', [
        'title' => '正在跳转支付',
        'pay'   => $r,
        'order' => $o,
    ]);
}

/** 异步通知：必须无登录、无 CSRF，纯文本回 success / fail */
function ctrl_pay_notify(): void
{
    header('Content-Type: text/plain; charset=utf-8');
    // 回调不需要会话；提前释放 session 锁，避免平台并发重试时互相阻塞
    if (session_status() === PHP_SESSION_ACTIVE) {
        session_write_close();
    }
    $params = array_merge($_GET, $_POST);
    // 关键坑：notify_url 是 ?r=pay_notify，平台会把 r 一起带回来。
    // r 不参与平台签名，留着会让验签必然失败。
    unset($params['r'], $params['p']);

    try {
        $r = pay_notify($params);
        echo !empty($r['ok']) ? 'success' : 'fail';
    } catch (Throwable $e) {
        echo 'fail';
    }
    exit;
}

/** 同步回跳：给用户看的落地页。发货以 notify / 查单为准，不凭这个页面的参数发货 */
function ctrl_pay_return(): void
{
    $params = array_merge($_GET, $_POST);
    unset($params['r'], $params['p']);

    $verified = false;
    $error = '';
    $order = null;
    $state = '';
    $note = '';

    try {
        $c = pay_conf();
        if ($c['pid'] !== '' && $c['key'] !== '') {
            $gw = pay_gateway($c);
            $v = $gw->verify($params);
            $verified = !empty($v['ok']);
            if ($verified) {
                $order = pay_order_by_no((string)$v['out_trade_no']);
                if ($order) {
                    if (!empty($v['paid'])) {
                        // 主动查一次：通知可能比回跳晚到，这里确认后就地补发货
                        $rec = pay_reconcile((int)$order['id']);
                        $state = (string)$rec['state'];
                        $note = (string)$rec['msg'];
                        $order = pay_order_get((int)$order['id']);
                    } else {
                        $state = 'pending';
                        $note = '平台返回的状态不是支付成功';
                    }
                } else {
                    $error = '找不到对应的订单';
                }
            } else {
                $error = (string)$v['error'];
            }
        } else {
            $error = '本站还没配置支付参数';
        }
    } catch (Throwable $e) {
        $error = $e->getMessage();
    }

    view('pay_return', [
        'title'    => '支付结果',
        'verified' => $verified,
        'error'    => $error,
        'order'    => $order,
        'state'    => $state,
        'note'     => $note,
        'logged'   => !empty(current_user()),
    ], false);
}

/**
 * 后台：支付设置 / 订单对账 / 退款
 */
function ctrl_admin_pay(): void
{
    $u = require_admin();
    $uid = (int)$u['id'];

    if (is_post()) {
        csrf_check();
        $action = post('action');
        try {
            if ($action === 'save') {
                $api = trim(post('pay_api', 'https://pay.cfxcc.cn'));
                if (!preg_match('#^https?://#i', $api)) {
                    throw new RuntimeException('接口地址要以 http:// 或 https:// 开头');
                }
                $pid = trim(post('pay_pid', ''));
                if ($pid !== '' && !preg_match('/^\d+$/', $pid)) {
                    throw new RuntimeException('商户 ID 只能是数字');
                }
                $methods = $_POST['methods'] ?? [];
                $methods = is_array($methods) ? array_values(array_intersect(array_map('strval', $methods), array_keys(pay_methods_all()))) : [];

                setting_set('pay_gateway', 'epay');
                setting_set('pay_api', rtrim($api, '/'));
                setting_set('pay_pid', $pid);
                setting_set('pay_methods', implode(',', $methods));
                setting_set('pay_use_mapi', post('pay_use_mapi') === '1' ? '1' : '0');
                setting_set('pay_title_prefix', mb_substr(trim(post('pay_title_prefix', '')), 0, 30));

                $newKey = trim((string)($_POST['pay_key'] ?? ''));
                if ($newKey !== '') {
                    setting_set('pay_key', secret_encrypt($newKey));
                }
                // 只有配齐了才允许打开，避免开关开了前台一片报错
                $wantOn = post('pay_enabled') === '1';
                $conf = pay_conf(true);
                if ($wantOn && ($conf['pid'] === '' || $conf['key'] === '' || $conf['methods'] === [])) {
                    setting_set('pay_enabled', '0');
                    throw new RuntimeException('商户号、商户密钥、支付方式三项没配齐，开关保持关闭');
                }
                setting_set('pay_enabled', $wantOn ? '1' : '0');
                pay_conf(true);
                audit('pay_save', 'enabled=' . ($wantOn ? '1' : '0') . ' pid=' . $pid);
                flash('支付设置已保存');
                redirect(u('admin_pay'));
            }

            if ($action === 'test') {
                $c = pay_conf(true);
                if ($c['pid'] === '' || $c['key'] === '') {
                    throw new RuntimeException('先填商户 ID 和商户密钥');
                }
                $r = pay_gateway($c)->probe();
                flash((!empty($r['ok']) ? '✓ ' : '✗ ') . (string)$r['message'], !empty($r['ok']) ? 'ok' : 'err');
                redirect(u('admin_pay'));
            }

            if ($action === 'query') {
                $r = pay_reconcile((int)post('order_id', '0'));
                flash((!empty($r['ok']) ? '✓ ' : '✗ ') . (string)$r['msg'], !empty($r['ok']) ? 'ok' : 'err');
                redirect(u('admin_pay'));
            }

            if ($action === 'close') {
                pay_order_close((int)post('order_id', '0'));
                audit('pay_order_close', 'order=' . (int)post('order_id', '0'));
                flash('订单已关闭');
                redirect(u('admin_pay'));
            }

            if ($action === 'refund') {
                $r = pay_refund((int)post('order_id', '0'), mb_substr(trim(post('reason')), 0, 100));
                flash('退款已提交；' . (string)$r['note']);
                redirect(u('admin_pay'));
            }
        } catch (Throwable $e) {
            flash($e->getMessage(), 'err');
            redirect(u('admin_pay'));
        }
    }

    $c = pay_conf(true);
    $today = date('Y-m-d 00:00:00');
    view('admin_pay', [
        'title'    => '支付设置',
        'conf'     => $c,
        'ready'    => pay_ready(),
        'keyMask'  => $c['key'] !== '' ? secret_mask($c['key']) : '',
        'methodsAll' => pay_methods_all(),
        'orders'   => all(
            'SELECT o.*, p.name AS plan_name, u.username FROM ' . tbl('ai_orders') . ' o
             LEFT JOIN ' . tbl('ai_plans') . ' p ON p.id = o.plan_id
             LEFT JOIN ' . tbl('users') . ' u ON u.id = o.user_id
             WHERE o.channel = ? OR o.status = ? ORDER BY o.id DESC LIMIT 60',
            ['epay', 'pending']
        ),
        'events'   => all('SELECT * FROM ' . tbl('pay_events') . ' ORDER BY id DESC LIMIT 40'),
        'stat'     => [
            'paid_today'   => (int)val('SELECT COUNT(*) FROM ' . tbl('ai_orders') . ' WHERE status = ? AND channel = ? AND paid_at >= ?', ['paid', 'epay', $today], 0),
            'amount_today' => (int)val('SELECT COALESCE(SUM(amount_cents),0) FROM ' . tbl('ai_orders') . ' WHERE status = ? AND channel = ? AND paid_at >= ?', ['paid', 'epay', $today], 0),
            'amount_all'   => (int)val('SELECT COALESCE(SUM(amount_cents),0) FROM ' . tbl('ai_orders') . ' WHERE status = ? AND channel = ?', ['paid', 'epay'], 0),
            'pending'      => (int)val('SELECT COUNT(*) FROM ' . tbl('ai_orders') . ' WHERE status = ? AND amount_cents > 0', ['pending'], 0),
        ],
    ]);
}
