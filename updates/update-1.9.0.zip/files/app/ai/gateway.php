<?php
declare(strict_types=1);

/**
 * AI 协议适配层：一套内部消息格式，适配三家原生协议。
 *
 *   openai     POST {base}/chat/completions        （DeepSeek/Kimi/通义/豆包/智谱/Ollama/vLLM 都走这个）
 *   anthropic  POST {base}/v1/messages             （x-api-key + anthropic-version）
 *   gemini     POST {base}/v1beta/models/{m}:generateContent?key=…
 *
 * 只做「发请求、取文本、取 token 用量、把错误翻成人话」，计费与业务在 billing/service 里。
 */

class AiError extends RuntimeException
{
    /** auth | rate | quota | timeout | network | bad_response | bad_config */
    public string $kind;

    public function __construct(string $kind, string $message, int $code = 0)
    {
        parent::__construct($message, $code);
        $this->kind = $kind;
    }
}

function ai_protocols(): array
{
    return ['openai' => 'OpenAI 兼容', 'anthropic' => 'Anthropic', 'gemini' => 'Google Gemini'];
}

/** 允许的协议，非法值一律当 openai */
function ai_protocol(string $p): string
{
    return isset(ai_protocols()[$p]) ? $p : 'openai';
}

/** 单次输入字符上限（settings 可调），防止把整库倒进去 */
function ai_max_input(): int
{
    $n = (int)setting_get('ai_max_input', '8000');
    return $n >= 500 ? min($n, 200000) : 8000;
}

/** 模型行 → 明文密钥（库里是 secret_encrypt 后的，可能为旧版明文） */
function ai_model_secret(array $m): string
{
    return secret_decrypt((string)($m['api_key'] ?? ''));
}

/** 对外展示用的模型信息（绝不带密钥） */
function ai_model_public(array $m): array
{
    return [
        'id'       => (int)$m['id'],
        'name'     => (string)$m['name'],
        'protocol' => (string)$m['protocol'],
        'model'    => (string)$m['model_key'],
        'credits'  => (int)$m['credits'],
        'owner'    => (int)($m['owner_id'] ?? 0) === 0 ? 'system' : 'self',
        'note'     => (string)($m['note'] ?? ''),
        'enabled'  => (int)$m['enabled'] === 1,
    ];
}

/** 拼 base 与路径，避免重复斜杠和重复后缀 */
function ai_join_url(string $base, string $path): string
{
    $base = rtrim(trim($base), '/');
    if ($base === '') {
        throw new AiError('bad_config', '模型地址（Base URL）没填');
    }
    if (!preg_match('#^https?://#i', $base)) {
        $base = 'https://' . $base;
    }
    if (str_ends_with(strtolower($base), strtolower($path))) {
        return $base;
    }
    return $base . $path;
}

/**
 * 把内部消息 [{role:system|user|assistant, content:string}] 转成各家请求体。
 * 返回 ['url','headers','body']。
 */
function ai_build_request(array $m, array $messages, array $opts = []): array
{
    $key = ai_model_secret($m);
    if ($key === '') {
        throw new AiError('bad_config', '这个模型还没配置 API Key');
    }
    $proto = ai_protocol((string)$m['protocol']);
    $model = (string)$m['model_key'];
    $maxTokens = (int)($opts['max_tokens'] ?? $m['max_tokens'] ?? 2048);
    $temp = (float)($opts['temperature'] ?? $m['temperature'] ?? 0.3);
    if ($maxTokens < 1) {
        $maxTokens = 1024;
    }
    $temp = max(0.0, min(2.0, $temp));

    $system = '';
    $turns = [];
    foreach ($messages as $msg) {
        $role = (string)($msg['role'] ?? 'user');
        $text = (string)($msg['content'] ?? '');
        if ($text === '') {
            continue;
        }
        if ($role === 'system') {
            $system = $system === '' ? $text : $system . "\n\n" . $text;
            continue;
        }
        $role = $role === 'assistant' ? 'assistant' : 'user';
        // 相邻同角色合并：有的上游对连续 user 会报错
        $last = count($turns) - 1;
        if ($last >= 0 && $turns[$last]['role'] === $role) {
            $turns[$last]['content'] .= "\n\n" . $text;
        } else {
            $turns[] = ['role' => $role, 'content' => $text];
        }
    }
    if (!$turns) {
        throw new AiError('bad_config', '没有可发送的内容');
    }

    if ($proto === 'anthropic') {
        $url = ai_join_url((string)$m['base_url'], '/v1/messages');
        $body = [
            'model' => $model,
            'max_tokens' => $maxTokens,
            'temperature' => $temp,
            'messages' => array_map(fn($t) => ['role' => $t['role'], 'content' => $t['content']], $turns),
        ];
        if ($system !== '') {
            $body['system'] = $system;
        }
        return [
            'url' => $url,
            'headers' => ['x-api-key: ' . $key, 'anthropic-version: 2023-06-01'],
            'body' => $body,
        ];
    }

    if ($proto === 'gemini') {
        $base = rtrim(trim((string)$m['base_url']), '/');
        if (!preg_match('#^https?://#i', $base)) {
            $base = 'https://' . $base;
        }
        $url = $base . '/v1beta/models/' . rawurlencode($model) . ':generateContent?key=' . rawurlencode($key);
        $contents = [];
        foreach ($turns as $t) {
            $contents[] = [
                'role' => $t['role'] === 'assistant' ? 'model' : 'user',
                'parts' => [['text' => $t['content']]],
            ];
        }
        $body = [
            'contents' => $contents,
            'generationConfig' => ['maxOutputTokens' => $maxTokens, 'temperature' => $temp],
        ];
        if ($system !== '') {
            $body['systemInstruction'] = ['parts' => [['text' => $system]]];
        }
        return ['url' => $url, 'headers' => [], 'body' => $body];
    }

    // openai 兼容
    $url = ai_join_url((string)$m['base_url'], '/chat/completions');
    $all = $system !== '' ? array_merge([['role' => 'system', 'content' => $system]], $turns) : $turns;
    return [
        'url' => $url,
        'headers' => ['Authorization: Bearer ' . $key],
        'body' => [
            'model' => $model,
            'messages' => $all,
            'max_tokens' => $maxTokens,
            'temperature' => $temp,
            'stream' => false,
        ],
    ];
}

/** 发请求；返回 ['code','body','ms']，网络层失败抛 AiError */
function ai_http(string $url, array $headers, array $body, int $timeout): array
{
    $payload = json_encode($body, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    if ($payload === false) {
        throw new AiError('bad_config', '请求体编码失败');
    }
    $timeout = $timeout > 5 ? min($timeout, 300) : 120;

    $ch = curl_init($url);
    $opts = [
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => $payload,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_FOLLOWLOCATION => false,
        CURLOPT_CONNECTTIMEOUT => 10,
        CURLOPT_TIMEOUT        => $timeout,
        CURLOPT_SSL_VERIFYPEER => true,
        CURLOPT_SSL_VERIFYHOST => 2,
        CURLOPT_USERAGENT      => 'kb-portal/' . (defined('APP_VERSION') ? APP_VERSION : '1.8') . ' (+php)',
        CURLOPT_HTTPHEADER     => array_merge(['Content-Type: application/json'], $headers),
    ];
    if (defined('CURLOPT_PROTOCOLS')) {
        $opts[CURLOPT_PROTOCOLS] = CURLPROTO_HTTPS | CURLPROTO_HTTP;
    }
    curl_setopt_array($ch, $opts);

    $t0 = microtime(true);
    $resp = curl_exec($ch);
    $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $err = curl_error($ch);
    $errno = (int)curl_errno($ch);
    curl_close($ch);
    $ms = (int)round((microtime(true) - $t0) * 1000);

    if ($resp === false) {
        if ($errno === 28) {
            throw new AiError('timeout', '模型响应超时（' . $timeout . 's），可以换更快的模型或减小输入');
        }
        throw new AiError('network', '连不上模型接口：' . ($err !== '' ? $err : '未知网络错误'));
    }
    return ['code' => $code, 'body' => (string)$resp, 'ms' => $ms];
}

/** 上游错误 → 人话 */
function ai_http_error(array $m, int $code, string $body): AiError
{
    $snippet = trim(preg_replace('/\s+/u', ' ', mb_substr($body, 0, 300)) ?? '');
    $msg = '';
    $d = json_decode($body, true);
    if (is_array($d)) {
        $msg = (string)($d['error']['message'] ?? $d['error']['msg'] ?? $d['message'] ?? $d['error'] ?? '');
    }
    $tail = $msg !== '' ? $msg : $snippet;

    if ($code === 401 || $code === 403) {
        return new AiError('auth', '模型密钥无效或没有权限（HTTP ' . $code . '）' . ($tail !== '' ? '：' . $tail : ''), $code);
    }
    if ($code === 429) {
        return new AiError('rate', '上游限流或额度用尽（HTTP 429）' . ($tail !== '' ? '：' . $tail : ''), $code);
    }
    if ($code === 404) {
        return new AiError('bad_config', '接口地址或模型名不对（HTTP 404）' . ($tail !== '' ? '：' . $tail : ''), $code);
    }
    if ($code >= 500) {
        return new AiError('network', '上游服务异常（HTTP ' . $code . '）' . ($tail !== '' ? '：' . $tail : ''), $code);
    }
    return new AiError('bad_response', '模型返回错误（HTTP ' . $code . '）' . ($tail !== '' ? '：' . $tail : ''), $code);
}

/** 解析响应正文 → ['text','usage'=>['in','out'],'model'] */
function ai_parse_response(array $m, string $body): array
{
    $d = json_decode($body, true);
    if (!is_array($d)) {
        throw new AiError('bad_response', '模型返回的不是 JSON：' . mb_substr($body, 0, 200));
    }
    $proto = ai_protocol((string)$m['protocol']);

    if ($proto === 'anthropic') {
        if (!empty($d['error'])) {
            throw new AiError('bad_response', '模型返回错误：' . (string)($d['error']['message'] ?? json_encode($d['error'])));
        }
        $text = '';
        foreach ((array)($d['content'] ?? []) as $c) {
            if (($c['type'] ?? '') === 'text') {
                $text .= (string)($c['text'] ?? '');
            }
        }
        return [
            'text' => trim($text),
            'usage' => [
                'in'  => (int)($d['usage']['input_tokens'] ?? 0),
                'out' => (int)($d['usage']['output_tokens'] ?? 0),
            ],
            'model' => (string)($d['model'] ?? ''),
        ];
    }

    if ($proto === 'gemini') {
        if (!empty($d['error'])) {
            throw new AiError('bad_response', '模型返回错误：' . (string)($d['error']['message'] ?? ''));
        }
        $text = '';
        foreach ((array)($d['candidates'][0]['content']['parts'] ?? []) as $p) {
            $text .= (string)($p['text'] ?? '');
        }
        $blocked = (string)($d['candidates'][0]['finishReason'] ?? '');
        if (trim($text) === '' && $blocked !== '') {
            throw new AiError('bad_response', '模型没有输出内容（finishReason=' . $blocked . '）');
        }
        return [
            'text' => trim($text),
            'usage' => [
                'in'  => (int)($d['usageMetadata']['promptTokenCount'] ?? 0),
                'out' => (int)($d['usageMetadata']['candidatesTokenCount'] ?? 0),
            ],
            'model' => (string)($d['modelVersion'] ?? ($d['model'] ?? '')),
        ];
    }

    if (!empty($d['error'])) {
        $e = $d['error'];
        throw new AiError('bad_response', '模型返回错误：' . (is_array($e) ? (string)($e['message'] ?? json_encode($e)) : (string)$e));
    }
    $text = (string)($d['choices'][0]['message']['content'] ?? '');
    if (is_array($d['choices'][0]['message']['content'] ?? null)) {
        // 部分兼容实现把 content 拆成数组
        $buf = '';
        foreach ($d['choices'][0]['message']['content'] as $part) {
            $buf .= (string)($part['text'] ?? '');
        }
        $text = $buf;
    }
    if (trim($text) === '') {
        $fr = (string)($d['choices'][0]['finish_reason'] ?? '');
        if ($fr === 'length') {
            throw new AiError('bad_response', '输出被 max_tokens 截断了，把上限调大再试');
        }
        throw new AiError('bad_response', '模型返回了空内容');
    }
    return [
        'text' => trim($text),
        'usage' => [
            'in'  => (int)($d['usage']['prompt_tokens'] ?? 0),
            'out' => (int)($d['usage']['completion_tokens'] ?? 0),
        ],
        'model' => (string)($d['model'] ?? ''),
    ];
}

/**
 * 主入口：发一次对话。
 * 返回 ['text','usage'=>['in','out'],'model','latency_ms']
 */
function ai_chat(array $m, array $messages, array $opts = []): array
{
    $req = ai_build_request($m, $messages, $opts);
    $res = ai_http($req['url'], $req['headers'], $req['body'], (int)($m['timeout'] ?? 120));
    if ($res['code'] < 200 || $res['code'] >= 300) {
        throw ai_http_error($m, (int)$res['code'], (string)$res['body']);
    }
    $out = ai_parse_response($m, (string)$res['body']);
    $out['latency_ms'] = $res['ms'];
    return $out;
}

/** 后台「测试连接」：真发一次最小请求 */
function ai_probe(array $m): string
{
    $out = ai_chat($m, [
        ['role' => 'user', 'content' => 'ping，请只回复 ok'],
    ], ['max_tokens' => 16, 'temperature' => 0]);
    $t = mb_substr($out['text'] !== '' ? $out['text'] : '(空)', 0, 40);
    return '通了：' . $m['name'] . ' 回复「' . $t . '」，耗时 ' . $out['latency_ms'] . ' ms'
        . ($out['usage']['in'] + $out['usage']['out'] > 0
            ? '，tokens ' . $out['usage']['in'] . '/' . $out['usage']['out']
            : '');
}

/** 从模型输出里抠 JSON（容忍 ```json 围栏与前后废话） */
function ai_extract_json(string $text): ?array
{
    $t = trim($text);
    if (preg_match('/```(?:json)?\s*([\s\S]*?)```/i', $t, $m)) {
        $t = trim($m[1]);
    }
    $d = json_decode($t, true);
    if (is_array($d)) {
        return $d;
    }
    $start = strpos($t, '{');
    $end = strrpos($t, '}');
    if ($start !== false && $end !== false && $end > $start) {
        $d = json_decode(substr($t, $start, $end - $start + 1), true);
        if (is_array($d)) {
            return $d;
        }
    }
    $start = strpos($t, '[');
    $end = strrpos($t, ']');
    if ($start !== false && $end !== false && $end > $start) {
        $d = json_decode(substr($t, $start, $end - $start + 1), true);
        if (is_array($d)) {
            return $d;
        }
    }
    return null;
}
