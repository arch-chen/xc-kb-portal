<?php /** @var array $group @var array $rows @var array $pg @var string $kind @var bool $canWrite */ ?>
<section class="page-head">
  <div>
    <h1 class="page-title"><?= e($group['name']) ?></h1>
    <?php if ($group['description']): ?>
      <p class="page-desc"><?= e($group['description']) ?></p>
    <?php endif; ?>
  </div>
  <?php if ($canWrite): ?>
    <div class="page-actions">
      <a class="btn" href="<?= e(u('entry_edit', ['gid' => $group['id'], 'kind' => 'qa'])) ?>">＋ 新建问答</a>
      <a class="btn" href="<?= e(u('entry_edit', ['gid' => $group['id'], 'kind' => 'doc'])) ?>">＋ 新建文档</a>
    </div>
  <?php endif; ?>
</section>

<div class="chips">
  <a class="chip <?= $kind === '' ? 'on' : '' ?>" href="<?= e(u('g', ['slug' => $group['slug']])) ?>">全部 <?= (int)$pg['total'] ?></a>
  <a class="chip <?= $kind === 'qa' ? 'on' : '' ?>" href="<?= e(u('g', ['slug' => $group['slug'], 'kind' => 'qa'])) ?>">问答</a>
  <a class="chip <?= $kind === 'doc' ? 'on' : '' ?>" href="<?= e(u('g', ['slug' => $group['slug'], 'kind' => 'doc'])) ?>">文档</a>
</div>

<?php if (!$rows): ?>
  <div class="empty">
    这个分组还没有内容。
    <?php if ($canWrite): ?>
      <div class="empty-hint"><a href="<?= e(u('entry_edit', ['gid' => $group['id']])) ?>">新建第一条</a></div>
    <?php endif; ?>
  </div>
<?php else: ?>
  <div class="list">
    <?php foreach ($rows as $r): ?>
      <a class="list-row" href="<?= e(u($r['kind'] === 'doc' ? 'doc' : 'entry', ['id' => $r['id']])) ?>">
        <span class="tag <?= e($r['kind']) ?>"><?= $r['kind'] === 'doc' ? '文档' : '问答' ?></span>
        <span class="list-title">
          <?= e($r['title'] ?: mb_substr((string)$r['question'], 0, 60, 'UTF-8')) ?>
          <?php if ($r['kind'] === 'qa' && $r['question'] !== '' && $r['title'] !== $r['question']): ?>
            <em class="list-sub"><?= e(mb_substr((string)$r['question'], 0, 70, 'UTF-8')) ?></em>
          <?php endif; ?>
        </span>
        <span class="list-time"><?= e(human_date($r['updated_at'])) ?></span>
      </a>
    <?php endforeach; ?>
  </div>

  <?php if ($pg['pages'] > 1): ?>
    <nav class="pager">
      <?php for ($i = 1; $i <= $pg['pages']; $i++): ?>
        <?php if ($i === 1 || $i === $pg['pages'] || abs($i - $pg['page']) <= 2): ?>
          <a class="page <?= $i === $pg['page'] ? 'on' : '' ?>"
             href="<?= e(u('g', ['slug' => $group['slug'], 'kind' => $kind, 'p' => $i])) ?>"><?= $i ?></a>
        <?php endif; ?>
      <?php endfor; ?>
    </nav>
  <?php endif; ?>
<?php endif; ?>
