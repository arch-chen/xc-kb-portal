<?php /** @var array $rows @var array $groups @var array $perms @var ?string $newKey */ ?>
<section class="page-head">
  <div>
    <h1 class="page-title">我的 API Key</h1>
    <p class="page-desc">给 Agent 用的访问凭证。每个 Key 只对一个分组生效，读和写可以分开授权。</p>
  </div>
</section>

<?php if ($newKey): ?>
  <div class="newkey">
    <div class="newkey-title">Key 已生成，只显示这一次，请现在复制保存</div>
    <div class="newkey-row">
      <code id="newKeyText"><?= e($newKey) ?></code>
      <button class="btn" type="button" id="copyKey">复制</button>
    </div>
    <div class="newkey-hint">丢失只能吊销后重新创建。</div>
  </div>
<?php endif; ?>

<div class="two-col">
  <section class="panel">
    <h2 class="panel-title">新建 Key</h2>
    <?php if (!$groups): ?>
      <div class="empty">你还没有可访问的分组，请联系管理员授权。</div>
    <?php else: ?>
      <form method="post" action="<?= e(u('keys')) ?>" class="form">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="create">
        <label>名称
          <input type="text" name="name" placeholder="例如：客服 Agent" maxlength="60">
        </label>
        <label>绑定分组
          <select name="group_id" id="keyGroup" required>
            <?php foreach ($groups as $g): $p = $perms[(int)$g['id']] ?? ['read' => false, 'write' => false]; ?>
              <option value="<?= (int)$g['id'] ?>"
                      data-read="<?= $p['read'] ? 1 : 0 ?>"
                      data-write="<?= $p['write'] ? 1 : 0 ?>">
                <?= e($g['name']) ?><?= $p['write'] ? '（可读写）' : '（只读）' ?>
              </option>
            <?php endforeach; ?>
          </select>
        </label>
        <div class="checks">
          <label class="check"><input type="checkbox" name="can_read" value="1" id="canRead" checked> 读取</label>
          <label class="check"><input type="checkbox" name="can_write" value="1" id="canWrite"> 写入</label>
        </div>
        <div class="hint" id="scopeHint">写权限需要你本身拥有该分组的写权限，否则不会生效。</div>
        <label>有效期（留空为永久）
          <input type="date" name="expires_at">
        </label>
        <button class="btn primary" type="submit">生成 Key</button>
      </form>
    <?php endif; ?>
  </section>

  <section class="panel">
    <h2 class="panel-title">Agent 接入方式</h2>
    <div class="prose small">
      <p>把 Key 放在请求头里，调用下面这些接口（把 <code>你的Key</code> 换成刚生成的）：</p>
      <pre><code># 我是谁、有哪些权限
curl -H "Authorization: Bearer 你的Key" \
  <?= e(base_url()) ?>/api.php?path=/v1/me

# 搜索本分组
curl -H "Authorization: Bearer 你的Key" \
  "<?= e(base_url()) ?>/api.php?path=/v1/search&q=关键词&limit=5"

# 新增一条问答（需要写权限）
curl -X POST -H "Authorization: Bearer 你的Key" \
  -H "Content-Type: application/json" \
  -d '{"kind":"qa","question":"问题","body":"答案"}' \
  "<?= e(base_url()) ?>/api.php?path=/v1/entries"</code></pre>
      <p>如果服务器开了伪静态，也可以直接用 <code><?= e(base_url()) ?>/api/v1/search?q=...</code>。</p>
    </div>
  </section>
</div>

<section class="panel">
  <h2 class="panel-title">已创建的 Key</h2>
  <?php if (!$rows): ?>
    <div class="empty">还没有创建过 Key。</div>
  <?php else: ?>
    <div class="table-wrap">
      <table class="table">
        <thead>
          <tr>
            <th>名称</th><th>分组</th><th>权限</th><th>状态</th><th>最后使用</th><th>创建</th><th></th>
          </tr>
        </thead>
        <tbody>
        <?php foreach ($rows as $r):
            $expired = $r['expires_at'] && strtotime((string)$r['expires_at']) < time();
            $state = (int)$r['revoked'] === 1 ? '已吊销' : ($expired ? '已过期' : '有效');
        ?>
          <tr>
            <td><?= e($r['name']) ?><div class="mono tiny"><?= e($r['key_prefix']) ?>…</div></td>
            <td><?= e($r['group_name'] ?: '—') ?></td>
            <td>
              <?= (int)$r['can_read'] ? '读' : '' ?><?= (int)$r['can_read'] && (int)$r['can_write'] ? ' + ' : '' ?><?= (int)$r['can_write'] ? '写' : '' ?>
            </td>
            <td><span class="pill <?= $state === '有效' ? 'ok' : 'off' ?>"><?= $state ?></span></td>
            <td class="tiny"><?= e($r['last_used_at'] ? human_date($r['last_used_at']) : '未使用') ?></td>
            <td class="tiny"><?= e(substr((string)$r['created_at'], 0, 10)) ?></td>
            <td class="right">
              <?php if ((int)$r['revoked'] === 0): ?>
                <form method="post" action="<?= e(u('keys')) ?>" onsubmit="return confirm('吊销后使用该 Key 的 Agent 会立刻失效，确定？')">
                  <?= csrf_field() ?>
                  <input type="hidden" name="action" value="revoke">
                  <input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
                  <button class="link danger" type="submit">吊销</button>
                </form>
              <?php endif; ?>
            </td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php endif; ?>
</section>
