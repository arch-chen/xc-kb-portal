<?php /** @var array $user @var array $groups @var array $perms */ ?>
<div class="crumbs">
  <a href="<?= e(u('admin')) ?>">后台</a><span>/</span>
  <a href="<?= e(u('admin_users')) ?>">用户</a><span>/</span>
  <span class="crumb-cur">分组授权</span>
</div>

<section class="page-head">
  <div>
    <h1 class="page-title">分组授权 · <?= e($user['username']) ?></h1>
    <p class="page-desc">
      勾选他能读的分组。写权限通常不用给人，除非需要人工编辑内容；API Key 的写权限也不会超过这里。
    </p>
  </div>
</section>

<form method="post" action="<?= e(u('admin_perm', ['uid' => $user['id']])) ?>">
  <?= csrf_field() ?>
  <section class="panel">
    <div class="table-wrap">
      <table class="table perm-table">
        <thead>
          <tr><th>分组</th><th>条目</th><th class="c">可读</th><th class="c">可写</th></tr>
        </thead>
        <tbody>
        <?php foreach ($groups as $g): $p = $perms[(int)$g['id']] ?? ['read' => false, 'write' => false]; ?>
          <tr>
            <td>
              <strong><?= e($g['name']) ?></strong>
              <div class="tiny muted mono"><?= e($g['slug']) ?></div>
            </td>
            <td class="tiny"><?= group_entry_count((int)$g['id']) ?></td>
            <td class="c">
              <input type="checkbox" name="read[]" value="<?= (int)$g['id'] ?>"
                     <?= $p['read'] ? 'checked' : '' ?>>
            </td>
            <td class="c">
              <input type="checkbox" name="write[]" value="<?= (int)$g['id'] ?>"
                     <?= $p['write'] ? 'checked' : '' ?>>
            </td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
    <?php if (!$groups): ?>
      <div class="empty">还没有分组，先去 <a href="<?= e(u('admin_groups')) ?>">分组管理</a> 建一个。</div>
    <?php endif; ?>
    <div class="form-actions">
      <button class="btn primary" type="submit">保存权限</button>
      <span class="hint">勾了「可写」会自动包含「可读」的语义，但建议两个都勾。</span>
    </div>
  </section>
</form>
