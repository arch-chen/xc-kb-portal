<?php
/** @var string $content */
$u = current_user();
$navGroups = $u ? visible_groups((int)$u['id']) : [];
$activeGroup = get_q('g', '');
$route = get_q('r');
$f = flash();
?>
<!DOCTYPE html>
<html lang="zh-CN" data-theme="system">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e($title ?? app_name()) ?></title>
<link rel="stylesheet" href="<?= e(asset('app.css')) ?>?v=<?= e(APP_VERSION) ?>">
<script>
(function () {
  try {
    var t = localStorage.getItem('kb-theme') || 'system';
    document.documentElement.setAttribute('data-theme', t);
  } catch (e) {}
})();
</script>
</head>
<body>
<div class="shell">
  <aside class="sidebar" id="sidebar">
    <a class="brand" href="<?= e(u()) ?>">
      <span class="brand-mark">知</span>
      <span class="brand-text"><?= e(app_name()) ?></span>
    </a>

    <form class="side-search" action="<?= e(u('search')) ?>" method="get">
      <input type="hidden" name="r" value="search">
      <input type="search" name="q" placeholder="搜索…" value="<?= e(get_q('q')) ?>">
    </form>

    <div class="side-section">
      <div class="side-title">我的分组</div>
      <nav class="side-nav">
        <?php if (!$navGroups): ?>
          <div class="side-empty">还没有被授权的分组</div>
        <?php endif; ?>
        <?php foreach ($navGroups as $g): ?>
          <a class="side-item <?= (string)$g['slug'] === $activeGroup ? 'active' : '' ?>"
             href="<?= e(u('g', ['slug' => $g['slug']])) ?>">
            <span class="dot"></span>
            <span class="side-item-text"><?= e($g['name']) ?></span>
          </a>
        <?php endforeach; ?>
      </nav>
    </div>

    <div class="side-foot">
      <a class="side-item" href="<?= e(u('group_new')) ?>"><span class="ico">＋</span>新建分组</a>
      <a class="side-item" href="<?= e(u('keys')) ?>"><span class="ico">🔑</span>我的 API Key</a>
      <?php if (is_admin($u)): ?>
        <a class="side-item" href="<?= e(u('admin')) ?>"><span class="ico">⚙</span>管理后台</a>
      <?php endif; ?>
      <button type="button" class="side-item theme-btn" id="themeBtn">
        <span class="ico" id="themeIco">◐</span><span id="themeLabel">跟随系统</span>
      </button>
      <form method="post" action="<?= e(u('logout')) ?>" class="logout-form">
        <?= csrf_field() ?>
        <button type="submit" class="side-item"><span class="ico">↪</span>退出登录</button>
      </form>
    </div>
  </aside>

  <main class="main">
    <div class="topbar">
      <button class="menu-btn" type="button" id="menuBtn" aria-label="菜单">☰</button>
      <span class="who"><?= e($u['display_name'] ?: $u['username']) ?><?= is_admin($u) ? ' · 管理员' : '' ?></span>
    </div>

    <?php if ($f): ?>
      <div class="flash <?= e($f['t']) ?>"><?= e($f['m']) ?></div>
    <?php endif; ?>

    <?= $content ?>
  </main>
</div>
<script src="<?= e(asset('app.js')) ?>?v=<?= e(APP_VERSION) ?>"></script>
</body>
</html>
