(function () {
  'use strict';

  var MODES = ['system', 'light', 'dark'];
  var LABEL = { system: '跟随系统', light: '亮色', dark: '暗色' };
  var ICON = { system: '◐', light: '☀', dark: '☾' };

  function current() {
    var t = document.documentElement.getAttribute('data-theme') || 'system';
    return MODES.indexOf(t) >= 0 ? t : 'system';
  }

  function apply(mode) {
    document.documentElement.setAttribute('data-theme', mode);
    try { localStorage.setItem('kb-theme', mode); } catch (e) {}
    var l = document.getElementById('themeLabel');
    var i = document.getElementById('themeIco');
    if (l) l.textContent = LABEL[mode];
    if (i) i.textContent = ICON[mode];
  }

  var btn = document.getElementById('themeBtn');
  if (btn) {
    var lbl = document.getElementById('themeLabel');
    var ico = document.getElementById('themeIco');
    if (lbl) lbl.textContent = LABEL[current()];
    if (ico) ico.textContent = ICON[current()];
    btn.addEventListener('click', function () {
      var next = MODES[(MODES.indexOf(current()) + 1) % MODES.length];
      apply(next);
    });
  }

  // 移动端菜单
  var menuBtn = document.getElementById('menuBtn');
  var sidebar = document.getElementById('sidebar');
  if (menuBtn && sidebar) {
    menuBtn.addEventListener('click', function () {
      sidebar.classList.toggle('open');
    });
    document.addEventListener('click', function (ev) {
      if (window.innerWidth > 900) return;
      if (!sidebar.classList.contains('open')) return;
      if (sidebar.contains(ev.target) || menuBtn.contains(ev.target)) return;
      sidebar.classList.remove('open');
    });
  }

  // 复制新 Key
  var copyBtn = document.getElementById('copyKey');
  if (copyBtn) {
    copyBtn.addEventListener('click', function () {
      var el = document.getElementById('newKeyText');
      if (!el) return;
      var text = el.textContent || '';
      var done = function () {
        var old = copyBtn.textContent;
        copyBtn.textContent = '已复制';
        setTimeout(function () { copyBtn.textContent = old; }, 1600);
      };
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(text).then(done, done);
      } else {
        var ta = document.createElement('textarea');
        ta.value = text;
        document.body.appendChild(ta);
        ta.select();
        try { document.execCommand('copy'); } catch (e) {}
        document.body.removeChild(ta);
        done();
      }
    });
  }

  // 建 Key 时按用户实际权限禁用「写」
  var groupSel = document.getElementById('keyGroup');
  var canWrite = document.getElementById('canWrite');
  var canRead = document.getElementById('canRead');
  var hint = document.getElementById('scopeHint');
  if (groupSel && canWrite && canRead) {
    var sync = function () {
      var opt = groupSel.options[groupSel.selectedIndex];
      if (!opt) return;
      var hasWrite = opt.getAttribute('data-write') === '1';
      var hasRead = opt.getAttribute('data-read') === '1';
      canWrite.disabled = !hasWrite;
      if (!hasWrite) canWrite.checked = false;
      canRead.checked = hasRead ? canRead.checked : true;
      if (hint) {
        hint.textContent = hasWrite
          ? '该分组你可以写，勾上「写入」后 Agent 才能新增或修改内容。'
          : '你在这个分组只有读权限，写选项已禁用。';
      }
    };
    groupSel.addEventListener('change', sync);
    sync();
  }

  // 条目编辑：切换问答/文档
  var kindSelect = document.getElementById('kindSelect');
  var questionRow = document.getElementById('questionRow');
  var linksPanel = document.getElementById('linksPanel');
  if (kindSelect) {
    var syncKind = function () {
      var isDoc = kindSelect.value === 'doc';
      if (linksPanel) linksPanel.style.display = isDoc ? '' : 'none';
      if (questionRow) questionRow.style.display = isDoc ? 'none' : '';
    };
    kindSelect.addEventListener('change', syncKind);
    syncKind();
  }
})();
