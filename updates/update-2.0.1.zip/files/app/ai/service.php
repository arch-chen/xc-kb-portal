<?php
declare(strict_types=1);

/**
 * AI 业务场景：对话、答案优化、文本转 QA 草稿。
 *
 * 统一流程（谁都不许绕过）：选模型 → 权益校验 → 预扣积分 → 调网关 → 记日志 →（失败则退款）。
 * 结果一律「先给建议、由人确认后入库」，AI 不直接改知识库，避免污染版本记录。
 */

/** 可给这个用户用的模型：系统模型 + 自己的模型 */
function ai_models_for(int $uid): array
{
    return all(
        'SELECT * FROM ' . tbl('ai_models') . '
         WHERE enabled = 1 AND (COALESCE(owner_id, 0) = 0 OR owner_id = ?)
         ORDER BY owner_id, sort, id',
        [$uid]
    );
}

function ai_model_get(int $id): ?array
{
    return $id > 0 ? one('SELECT * FROM ' . tbl('ai_models') . ' WHERE id = ?', [$id]) : null;
}

/** 默认模型：系统里 sort 最小的那个 */
function ai_default_model_id(int $uid): int
{
    $rows = ai_models_for($uid);
    foreach ($rows as $r) {
        if ((int)$r['owner_id'] === 0) {
            return (int)$r['id'];
        }
    }
    return $rows ? (int)$rows[0]['id'] : 0;
}

function ai_log_call(int $uid, array $model, string $action, array $ctx, array $usage, int $credits, int $ms, string $status, string $error = ''): int
{
    return insert_row('ai_calls', [
        'user_id'    => $uid,
        'model_id'   => (int)$model['id'],
        'model_name' => mb_substr((string)$model['name'], 0, 60),
        'action'     => mb_substr($action, 0, 20),
        'group_id'   => (int)($ctx['group_id'] ?? 0),
        'entry_id'   => (int)($ctx['entry_id'] ?? 0),
        'tokens_in'  => (int)($usage['in'] ?? 0),
        'tokens_out' => (int)($usage['out'] ?? 0),
        'credits'    => $credits,
        'latency_ms' => $ms,
        'status'     => $status,
        'error'      => $error !== '' ? mb_substr($error, 0, 240) : null,
        'created_at' => now_str(),
    ]);
}

/**
 * 统一执行一次 AI 调用（含计费、日志、失败退款）。
 * 返回 ['text','usage','credits','balance','model','latency_ms','call_id']
 */
function ai_run(int $uid, int $modelId, string $action, array $messages, array $ctx = [], array $opts = []): array
{
    if (!ai_on()) {
        throw new AiError('disabled', 'AI 功能已被管理员关闭');
    }
    $user = one('SELECT * FROM ' . tbl('users') . ' WHERE id = ? AND status = 1', [$uid]);
    if (!$user) {
        throw new AiError('forbidden', '用户不存在或已停用');
    }
    $model = ai_model_get($modelId);
    if (!$model) {
        throw new AiError('bad_config', '模型不存在，请重新选择');
    }

    $ent = ai_entitlement($uid);
    $chk = ai_can_use_model($user, $model, $ent);
    if (!$chk['ok']) {
        $kind = str_contains($chk['reason'], '积分不足') ? 'insufficient' : 'forbidden';
        throw new AiError($kind, $chk['reason']);
    }

    $price = $chk['free'] ? 0 : (int)$model['credits'];
    if ($price > 0) {
        $hold = ai_credit_move($uid, -$price, 'ai_call', [
            'model_id' => (int)$model['id'], 'ref_type' => 'action', 'note' => 'AI：' . $action,
        ]);
        if (!$hold['ok']) {
            throw new AiError('insufficient', $hold['error']);
        }
    }

    $t0 = microtime(true);
    try {
        $out = ai_chat($model, $messages, $opts);
    } catch (Throwable $e) {
        $ms = (int)round((microtime(true) - $t0) * 1000);
        if ($price > 0) {
            ai_credit_move($uid, $price, 'refund', [
                'model_id' => (int)$model['id'], 'note' => '调用失败退回：' . $action,
            ]);
        }
        ai_log_call($uid, $model, $action, $ctx, ['in' => 0, 'out' => 0], 0, $ms, 'fail', $e->getMessage());
        throw $e;
    }

    $ms = (int)round((microtime(true) - $t0) * 1000);
    $callId = ai_log_call($uid, $model, $action, $ctx, $out['usage'], $price, (int)($out['latency_ms'] ?? $ms), 'ok');

    return [
        'text'       => (string)$out['text'],
        'usage'      => $out['usage'],
        'credits'    => $price,
        'balance'    => ai_balance($uid),
        'model'      => ai_model_public($model),
        'latency_ms' => (int)($out['latency_ms'] ?? $ms),
        'call_id'    => $callId,
    ];
}

/* ---------------- 提示词（可在后台 settings 覆盖） ---------------- */

function ai_prompt(string $code): array
{
    $defaults = [
        'chat' => [
            'system' => '你是跨境电商（Wayfair 平台）运营助手，服务对象是新手卖家。'
                . '回答要具体、可执行，给数字和步骤；不确定的地方明确说「需要确认」，不要编造平台政策。'
                . '涉及费用、时效、政策时提醒对方以平台后台为准。',
            'user' => '',
        ],
        'polish' => [
            'system' => '你是 Wayfair 群知识库的资深编辑。任务是把群里口语化、碎片化的问答，'
                . '整理成准确、可复用的标准答案。要求：\n'
                . '1. 不改变原意，不新增没有依据的信息；原文缺失的关键参数用「（待补充：…）」标出。\n'
                . '2. 结论先行，再给步骤或原因；能分点时用 Markdown 列表。\n'
                . '3. 保留具体的数字、时效、政策名称；删掉语气词、寒暄、重复。\n'
                . '4. 严格按这三段输出，不要加别的小标题：\n'
                . '## 优化后答案\n## 改动说明\n## 仍需确认',
            'user' => '',
        ],
        'extract' => [
            'system' => '你是知识库录入助手。从给定的群聊片段里，抽出可以独立成条的问答对。'
                . '规则：\n'
                . '1. 只抽「一个问题 + 一个明确回答」，纯提问没回答的不要抽，闲聊不要抽。\n'
                . '2. 问题改写成完整、可检索的一句话（不要「这个」「那个」这类指代）；回答保留原有关键信息与数字。\n'
                . '3. 原文没有的信息绝不补充。\n'
                . '4. 段落后提到的问题若回答在前文，也算一对。\n'
                . '5. 只输出 JSON，不要任何解释文字，格式：'
                . '{"items":[{"question":"...","answer":"..."}]}',
            'user' => '',
        ],
    ];
    $d = $defaults[$code] ?? ['system' => '', 'user' => ''];
    $sys = (string)setting_get('ai_prompt_' . $code . '_system', '');
    if (trim($sys) !== '') {
        $d['system'] = $sys;
    }
    return $d;
}

/** 输入长度护栏 */
function ai_check_input(string $text, string $what = '内容'): string
{
    $text = trim($text);
    if ($text === '') {
        throw new AiError('bad_config', $what . '不能为空');
    }
    $max = ai_max_input();
    if (mb_strlen($text) > $max) {
        throw new AiError('bad_config', $what . '太长了（' . mb_strlen($text) . ' 字），单次上限 ' . $max . ' 字，请分段处理');
    }
    return $text;
}

/* ---------------- 三个场景 ---------------- */

/** 通用对话 */
function ai_chat_flow(int $uid, int $modelId, string $text, array $history = [], array $ctx = []): array
{
    $p = ai_prompt('chat');
    $messages = [['role' => 'system', 'content' => $p['system']]];
    $count = 0;
    foreach ($history as $h) {
        if ($count >= 10) {
            break;
        }
        $role = (string)($h['role'] ?? 'user');
        $c = trim((string)($h['content'] ?? ''));
        if ($c === '' || !in_array($role, ['user', 'assistant'], true)) {
            continue;
        }
        $messages[] = ['role' => $role, 'content' => mb_substr($c, 0, 4000)];
        $count++;
    }
    $messages[] = ['role' => 'user', 'content' => ai_check_input($text, '问题')];
    return ai_run($uid, $modelId, 'chat', $messages, $ctx);
}

/**
 * 优化一条答案。
 * $in: ['entry_id'=>int, 'text'=>string] 二选一，entry_id 优先。
 */
function ai_polish_answer(int $uid, int $modelId, array $in): array
{
    $entryId = (int)($in['entry_id'] ?? 0);
    $question = trim((string)($in['question'] ?? ''));
    $answer = trim((string)($in['text'] ?? ''));
    $ctx = ['entry_id' => $entryId];

    if ($entryId > 0) {
        $e = one('SELECT * FROM ' . tbl('entries') . ' WHERE id = ? AND status = 1', [$entryId]);
        if (!$e) {
            throw new AiError('bad_config', '条目不存在或已删除');
        }
        if (!can_read_group($uid, (int)$e['group_id'])) {
            throw new AiError('forbidden', '你没有这个分组的权限');
        }
        $ctx['group_id'] = (int)$e['group_id'];
        $question = (string)$e['question'];
        $answer = (string)$e['body'];
    }

    $answer = ai_check_input($answer, '答案原文');
    $p = ai_prompt('polish');
    $user = "问题：\n" . ($question !== '' ? $question : '（无）') . "\n\n答案原文：\n" . $answer;
    $out = ai_run($uid, $modelId, 'polish', [
        ['role' => 'system', 'content' => $p['system']],
        ['role' => 'user', 'content' => $user],
    ], $ctx, ['max_tokens' => 3000]);

    $out['input'] = ['question' => $question, 'answer' => $answer];
    return $out;
}

/**
 * 群聊片段 → QA 草稿。
 * $in: ['text'=>string, 'max'=>int]
 */
function ai_extract_qa(int $uid, int $modelId, array $in): array
{
    $text = ai_check_input((string)($in['text'] ?? ''), '群聊内容');
    $max = (int)($in['max'] ?? 8);
    $max = $max > 0 ? min($max, 20) : 8;
    $p = ai_prompt('extract');
    $out = ai_run($uid, $modelId, 'extract', [
        ['role' => 'system', 'content' => $p['system']],
        ['role' => 'user', 'content' => "最多抽 {$max} 条。群聊片段：\n\n" . $text],
    ], [], ['max_tokens' => 4000, 'temperature' => 0.1]);

    $data = ai_extract_json($out['text']);
    $items = [];
    foreach ((array)($data['items'] ?? []) as $it) {
        $q = trim((string)($it['question'] ?? ''));
        $a = trim((string)($it['answer'] ?? ''));
        if ($q === '' || $a === '') {
            continue;
        }
        $items[] = ['question' => mb_substr($q, 0, 500), 'answer' => $a];
        if (count($items) >= $max) {
            break;
        }
    }
    $out['items'] = $items;
    $out['parse_ok'] = $items !== [];
    return $out;
}
