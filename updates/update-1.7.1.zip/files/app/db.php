<?php
declare(strict_types=1);

/**
 * 数据库层：PDO 单例 + 跨 SQLite / MySQL 的建表与查询封装。
 * 不依赖任何 Composer 包。
 */

function cfg(): array
{
    static $c = null;
    if ($c === null) {
        $file = BASE_PATH . '/config.php';
        if (!is_file($file)) {
            http_response_code(500);
            exit('未安装：请先访问 install.php 完成安装。');
        }
        /** @noinspection PhpIncludeInspection */
        $c = require $file;
    }
    return $c;
}

function db_driver(): string
{
    return (string)(cfg()['db']['driver'] ?? 'sqlite');
}

function db_prefix(): string
{
    return (string)(cfg()['db']['prefix'] ?? '');
}

/** 表名（带前缀） */
function tbl(string $name): string
{
    return db_prefix() . $name;
}

function db(): PDO
{
    static $pdo = null;
    if ($pdo instanceof PDO) {
        return $pdo;
    }
    $d = cfg()['db'];
    $opts = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ];
    try {
        if ($d['driver'] === 'sqlite') {
            $path = $d['sqlite_path'];
            $dir = dirname($path);
            if (!is_dir($dir)) {
                @mkdir($dir, 0775, true);
            }
            $pdo = new PDO('sqlite:' . $path, null, null, $opts);
            $pdo->exec('PRAGMA journal_mode = WAL');
            $pdo->exec('PRAGMA foreign_keys = ON');
            $pdo->exec('PRAGMA busy_timeout = 5000');
        } else {
            $dsn = sprintf('mysql:host=%s;port=%d;dbname=%s;charset=%s',
                $d['host'], (int)$d['port'], $d['database'], $d['charset'] ?: 'utf8mb4');
            $pdo = new PDO($dsn, $d['username'], $d['password'], $opts);
        }
    } catch (PDOException $e) {
        http_response_code(500);
        exit('数据库连接失败：' . htmlspecialchars($e->getMessage(), ENT_QUOTES, 'UTF-8'));
    }
    return $pdo;
}

function q(string $sql, array $params = []): PDOStatement
{
    $st = db()->prepare($sql);
    $st->execute($params);
    return $st;
}

function all(string $sql, array $params = []): array
{
    return q($sql, $params)->fetchAll();
}

function one(string $sql, array $params = []): ?array
{
    $r = q($sql, $params)->fetch();
    return $r === false ? null : $r;
}

function val(string $sql, array $params = [], $default = null)
{
    $r = q($sql, $params)->fetchColumn();
    return $r === false ? $default : $r;
}

/** 插入一行，返回自增 ID */
function insert_row(string $table, array $data): int
{
    $cols = array_keys($data);
    $ph = array_map(fn($c) => ':' . $c, $cols);
    $sql = 'INSERT INTO ' . tbl($table) . ' (' . implode(',', $cols) . ') VALUES (' . implode(',', $ph) . ')';
    q($sql, $data);
    return (int)db()->lastInsertId();
}

function update_row(string $table, int $id, array $data): void
{
    if (!$data) {
        return;
    }
    $set = [];
    foreach (array_keys($data) as $c) {
        $set[] = "$c = :$c";
    }
    $data['__id'] = $id;
    q('UPDATE ' . tbl($table) . ' SET ' . implode(', ', $set) . ' WHERE id = :__id', $data);
}

function now_str(): string
{
    return date('Y-m-d H:i:s');
}

/**
 * 建表。$fresh=true 时先删旧表（仅安装使用）。
 * 结构变更请走 migrations/ 下的迁移文件，不要改这里，否则老站升级会漏。
 */
function schema_install(bool $fresh = false): void
{
    $pdo = db();
    $my = db_driver() === 'mysql';
    $PK  = $my ? 'INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY' : 'INTEGER PRIMARY KEY AUTOINCREMENT';
    $INT = $my ? 'INT' : 'INTEGER';
    $TINY = $my ? 'TINYINT' : 'INTEGER';
    $TEXT = $my ? 'LONGTEXT' : 'TEXT';
    $VC   = fn(int $n) => $my ? "VARCHAR($n)" : 'TEXT';
    $DT   = $my ? 'DATETIME' : 'TEXT';
    $ENG  = $my ? ' ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci' : '';

    $tables = [];

    $tables['users'] = "CREATE TABLE IF NOT EXISTS {T}users (
        id $PK,
        username {$VC(64)} NOT NULL,
        password_hash {$VC(255)} NOT NULL,
        display_name {$VC(64)} NULL,
        email {$VC(190)} NULL,
        email_verified_at $DT NULL,
        notify_mail $TINY NOT NULL DEFAULT 1,
        role {$VC(16)} NOT NULL DEFAULT 'user',
        status $TINY NOT NULL DEFAULT 1,
        created_at $DT NULL,
        last_login_at $DT NULL
    )$ENG";

    $tables['groups'] = "CREATE TABLE IF NOT EXISTS {T}groups (
        id $PK,
        name {$VC(120)} NOT NULL,
        slug {$VC(120)} NOT NULL,
        description {$VC(500)} NULL,
        owner_id $INT NOT NULL DEFAULT 0,
        sort $INT NOT NULL DEFAULT 0,
        created_at $DT NULL
    )$ENG";

    $tables['group_user'] = "CREATE TABLE IF NOT EXISTS {T}group_user (
        id $PK,
        group_id $INT NOT NULL,
        user_id $INT NOT NULL,
        can_read $TINY NOT NULL DEFAULT 1,
        can_write $TINY NOT NULL DEFAULT 0,
        created_at $DT NULL
    )$ENG";

    $tables['entries'] = "CREATE TABLE IF NOT EXISTS {T}entries (
        id $PK,
        group_id $INT NOT NULL,
        kind {$VC(8)} NOT NULL DEFAULT 'qa',
        title {$VC(255)} NULL,
        question {$TEXT} NULL,
        body $TEXT NULL,
        source {$VC(120)} NULL,
        source_date {$VC(20)} NULL,
        qfp {$VC(64)} NULL,
        afp {$VC(64)} NULL,
        version $INT NOT NULL DEFAULT 1,
        status $TINY NOT NULL DEFAULT 1,
        created_by $INT NULL,
        created_at $DT NULL,
        updated_at $DT NULL
    )$ENG";

    $tables['entry_versions'] = "CREATE TABLE IF NOT EXISTS {T}entry_versions (
        id $PK,
        entry_id $INT NOT NULL,
        version $INT NOT NULL DEFAULT 1,
        title {$VC(255)} NULL,
        question $TEXT NULL,
        body $TEXT NULL,
        source {$VC(120)} NULL,
        source_date {$VC(20)} NULL,
        changed_by $INT NULL,
        created_at $DT NULL
    )$ENG";

    $tables['doc_links'] = "CREATE TABLE IF NOT EXISTS {T}doc_links (
        id $PK,
        doc_id $INT NOT NULL,
        entry_id $INT NOT NULL,
        sort $INT NOT NULL DEFAULT 0,
        note {$VC(500)} NULL
    )$ENG";

    $tables['api_keys'] = "CREATE TABLE IF NOT EXISTS {T}api_keys (
        id $PK,
        user_id $INT NOT NULL,
        name {$VC(120)} NOT NULL,
        key_prefix {$VC(24)} NOT NULL,
        key_hash {$VC(64)} NOT NULL,
        key_plain $TEXT NULL,
        group_id $INT NOT NULL,
        can_read $TINY NOT NULL DEFAULT 1,
        can_write $TINY NOT NULL DEFAULT 0,
        expires_at $DT NULL,
        last_used_at $DT NULL,
        revoked $TINY NOT NULL DEFAULT 0,
        created_at $DT NULL
    )$ENG";

    $tables['entry_grams'] = "CREATE TABLE IF NOT EXISTS {T}entry_grams (
        id $PK,
        entry_id $INT NOT NULL,
        gram {$VC(8)} NOT NULL
    )$ENG";

    $tables['settings'] = "CREATE TABLE IF NOT EXISTS {T}settings (
        k {$VC(64)} NOT NULL PRIMARY KEY,
        v $TEXT NULL
    )$ENG";

    $tables['throttle'] = "CREATE TABLE IF NOT EXISTS {T}throttle (
        id $PK,
        bucket {$VC(80)} NOT NULL,
        ts $DT NULL
    )$ENG";

    $tables['email_codes'] = "CREATE TABLE IF NOT EXISTS {T}email_codes (
        id $PK,
        email {$VC(190)} NOT NULL,
        purpose {$VC(16)} NOT NULL,
        code_hash {$VC(64)} NOT NULL,
        uid $INT NULL,
        tries $INT NOT NULL DEFAULT 0,
        expires_at $DT NULL,
        used_at $DT NULL,
        ip {$VC(64)} NULL,
        created_at $DT NULL
    )$ENG";

    $tables['mail_log'] = "CREATE TABLE IF NOT EXISTS {T}mail_log (
        id $PK,
        to_email {$VC(190)} NULL,
        user_id $INT NULL,
        subject {$VC(200)} NULL,
        kind {$VC(32)} NULL,
        ok $TINY NOT NULL DEFAULT 0,
        error {$VC(500)} NULL,
        created_at $DT NULL
    )$ENG";

    $tables['audit_log'] = "CREATE TABLE IF NOT EXISTS {T}audit_log (
        id $PK,
        user_id $INT NULL,
        action {$VC(64)} NOT NULL,
        detail {$VC(1000)} NULL,
        ip {$VC(64)} NULL,
        created_at $DT NULL
    )$ENG";

    /* ---------- 1.7.0 文件存储 ---------- */

    // 存储平台。config 是加密后的 JSON（AK/SK 明文绝不落库）
    $tables['storage_providers'] = "CREATE TABLE IF NOT EXISTS {T}storage_providers (
        id $PK,
        name {$VC(60)} NOT NULL,
        driver {$VC(16)} NOT NULL,
        config $TEXT NULL,
        enabled $TINY NOT NULL DEFAULT 0,
        is_primary $TINY NOT NULL DEFAULT 0,
        sort $INT NOT NULL DEFAULT 0,
        status {$VC(16)} NULL DEFAULT 'new',
        last_check_at $DT NULL,
        last_error {$VC(500)} NULL,
        last_sync_at $DT NULL,
        created_at $DT NULL
    )$ENG";

    $tables['attachments'] = "CREATE TABLE IF NOT EXISTS {T}attachments (
        id $PK,
        group_id $INT NOT NULL,
        entry_id $INT NULL,
        name {$VC(255)} NULL,
        ext {$VC(16)} NULL,
        mime {$VC(80)} NULL,
        size $INT NOT NULL DEFAULT 0,
        sha256 {$VC(64)} NULL,
        object_key {$VC(255)} NOT NULL,
        created_by $INT NULL,
        created_at $DT NULL,
        status $TINY NOT NULL DEFAULT 1
    )$ENG";

    // 每个文件在每个平台上的副本状态，是「灾备同步」的事实来源
    $tables['attachment_replicas'] = "CREATE TABLE IF NOT EXISTS {T}attachment_replicas (
        id $PK,
        attachment_id $INT NOT NULL,
        provider_id $INT NOT NULL,
        object_key {$VC(255)} NOT NULL,
        state {$VC(12)} NOT NULL DEFAULT 'ok',
        size $INT NOT NULL DEFAULT 0,
        synced_at $DT NULL,
        last_error {$VC(500)} NULL
    )$ENG";

    // 同步任务：分批推进，可中断续跑
    $tables['storage_jobs'] = "CREATE TABLE IF NOT EXISTS {T}storage_jobs (
        id $PK,
        provider_id $INT NOT NULL,
        kind {$VC(12)} NOT NULL DEFAULT 'sync',
        state {$VC(12)} NOT NULL DEFAULT 'running',
        total $INT NOT NULL DEFAULT 0,
        done $INT NOT NULL DEFAULT 0,
        failed $INT NOT NULL DEFAULT 0,
        cursor $INT NOT NULL DEFAULT 0,
        cloud_copies $INT NOT NULL DEFAULT 0,
        relayed $INT NOT NULL DEFAULT 0,
        message {$VC(500)} NULL,
        started_at $DT NULL,
        finished_at $DT NULL
    )$ENG";

    if ($fresh) {
        $order = ['storage_jobs', 'attachment_replicas', 'attachments', 'storage_providers', 'mail_log', 'email_codes', 'audit_log', 'throttle', 'entry_versions', 'entry_grams', 'doc_links', 'api_keys', 'entries', 'group_user', 'groups', 'settings', 'users'];
        foreach ($order as $t) {
            $pdo->exec('DROP TABLE IF EXISTS ' . tbl($t));
        }
    }

    foreach ($tables as $name => $sql) {
        $pdo->exec(str_replace('{T}', db_prefix(), $sql));
    }

    $idx = [
        'CREATE INDEX IF NOT EXISTS {T}idx_gu_user ON {T}group_user (user_id)',
        'CREATE INDEX IF NOT EXISTS {T}idx_gu_group ON {T}group_user (group_id)',
        'CREATE INDEX IF NOT EXISTS {T}idx_entries_group ON {T}entries (group_id)',
        'CREATE INDEX IF NOT EXISTS {T}idx_entries_kind ON {T}entries (kind)',
        'CREATE INDEX IF NOT EXISTS {T}idx_grams ON {T}entry_grams (gram)',
        'CREATE INDEX IF NOT EXISTS {T}idx_grams_entry ON {T}entry_grams (entry_id)',
        'CREATE INDEX IF NOT EXISTS {T}idx_keys_hash ON {T}api_keys (key_hash)',
        'CREATE INDEX IF NOT EXISTS {T}idx_doclinks_doc ON {T}doc_links (doc_id)',
        'CREATE INDEX IF NOT EXISTS {T}idx_entries_qfp ON {T}entries (group_id, qfp)',
        'CREATE INDEX IF NOT EXISTS {T}idx_versions_entry ON {T}entry_versions (entry_id)',
        'CREATE INDEX IF NOT EXISTS {T}idx_groups_owner ON {T}groups (owner_id)',
        'CREATE INDEX IF NOT EXISTS {T}idx_throttle ON {T}throttle (bucket, ts)',
        'CREATE INDEX IF NOT EXISTS {T}idx_users_email ON {T}users (email)',
        'CREATE INDEX IF NOT EXISTS {T}idx_codes_lookup ON {T}email_codes (email, purpose)',
        'CREATE INDEX IF NOT EXISTS {T}idx_maillog ON {T}mail_log (created_at)',
        'CREATE INDEX IF NOT EXISTS {T}idx_att_group ON {T}attachments (group_id)',
        'CREATE INDEX IF NOT EXISTS {T}idx_att_entry ON {T}attachments (entry_id)',
        'CREATE INDEX IF NOT EXISTS {T}idx_rep_att ON {T}attachment_replicas (attachment_id)',
        'CREATE INDEX IF NOT EXISTS {T}idx_rep_prov ON {T}attachment_replicas (provider_id)',
        'CREATE INDEX IF NOT EXISTS {T}idx_jobs_prov ON {T}storage_jobs (provider_id)',
    ];
    foreach ($idx as $sql) {
        try {
            $pdo->exec(str_replace('{T}', db_prefix(), $sql));
        } catch (Throwable $e) {
            // MySQL 5.x 不支持 CREATE INDEX IF NOT EXISTS，忽略重复索引错误
        }
    }

    // MySQL 下 username / slug 需要唯一约束（SQLite 用唯一索引也能实现）
    // 昵称也要唯一：MySQL 的 utf8mb4_unicode_ci 本身不区分大小写，SQLite 得显式 COLLATE NOCASE
    $uniq = [
        'CREATE UNIQUE INDEX IF NOT EXISTS {T}uq_users_username ON {T}users (username)',
        'CREATE UNIQUE INDEX IF NOT EXISTS {T}uq_groups_slug ON {T}groups (slug)',
        'CREATE UNIQUE INDEX IF NOT EXISTS {T}uq_gu ON {T}group_user (group_id, user_id)',
    ];
    $uniq[] = db_driver() === 'mysql'
        ? 'CREATE UNIQUE INDEX {T}uq_users_nick ON {T}users (display_name)'
        : 'CREATE UNIQUE INDEX IF NOT EXISTS {T}uq_users_nick ON {T}users (display_name COLLATE NOCASE)';
    foreach ($uniq as $sql) {
        try {
            $pdo->exec(str_replace('{T}', db_prefix(), $sql));
        } catch (Throwable $e) {
        }
    }

    // 全新安装也要有默认的本地磁盘平台（老站升级由 migrations/1.7.0.php 补）
    try {
        $n = (int)$pdo->query('SELECT COUNT(*) FROM ' . tbl('storage_providers'))->fetchColumn();
        if ($n === 0) {
            insert_row('storage_providers', [
                'name' => '本地磁盘',
                'driver' => 'local',
                'config' => json_encode(['root' => 'storage/uploads'], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
                'enabled' => 1,
                'is_primary' => 1,
                'sort' => 0,
                'status' => 'ok',
                'created_at' => now_str(),
            ]);
        }
        if (val('SELECT COUNT(*) FROM ' . tbl('settings') . ' WHERE k = ?', ['file_max_mb'], 0) == 0) {
            q('INSERT INTO ' . tbl('settings') . ' (k, v) VALUES (?, ?)', ['file_max_mb', '20']);
        }
    } catch (Throwable $e) {
        // 老库结构还没迁移时忽略
    }
}

function setting_get(string $k, $default = null)
{
    $v = val('SELECT v FROM ' . tbl('settings') . ' WHERE k = ?', [$k], null);
    return $v === null ? $default : $v;
}

function setting_set(string $k, $v): void
{
    $exists = val('SELECT COUNT(*) FROM ' . tbl('settings') . ' WHERE k = ?', [$k], 0);
    if ($exists) {
        q('UPDATE ' . tbl('settings') . ' SET v = ? WHERE k = ?', [$v, $k]);
    } else {
        q('INSERT INTO ' . tbl('settings') . ' (k, v) VALUES (?, ?)', [$k, $v]);
    }
}

/** MCP 接入是否开放。默认开；1.5.0 之前没有这个设置项，读不到时也按开处理。 */
function mcp_enabled(): bool
{
    return setting_get('mcp_enabled', '1') !== '0';
}

function audit(string $action, string $detail = ''): void
{
    try {
        insert_row('audit_log', [
            'user_id'    => current_user()['id'] ?? null,
            'action'     => $action,
            'detail'     => mb_substr($detail, 0, 900),
            'ip'         => $_SERVER['REMOTE_ADDR'] ?? '',
            'created_at' => now_str(),
        ]);
    } catch (Throwable $e) {
    }
}
