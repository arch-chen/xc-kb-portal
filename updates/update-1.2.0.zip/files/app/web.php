<?php
declare(strict_types=1);

/** 前台与后台的页面控制器（路由处理函数） */

/* ---------------- 登录 ---------------- */

function ctrl_login(): void
{
    if (current_user()) {
        redirect(u());
    }
    $err = '';
    if (is_post()) {
        csrf_check();
        $wait = login_locked_for();
        if ($wait > 0) {
            $err = '尝试次数过多，请 ' . $wait . ' 秒后再试';
        } elseif (login_attempt(post('username'), post('password'))) {
            $to = $_SESSION['after_login'] ?? '';
            unset($_SESSION['after_login']);
            redirect($to !== '' ? $to : u());
        } else {
            $err = '账号或密码不正确';
        }
    }
    view('login', ['err' => $err, 'title' => '登录'], false);
}

function ctrl_logout(): void
{
    if (is_post()) {
        csrf_check();
        logout();
    }
    redirect(u('login'));
}

/* ---------------- 注册 ---------------- */

function ctrl_register(): void
{
    if (current_user()) {
        redirect(u());
    }
    if (!register_allowed()) {
        http_response_code(403);
        view('register_closed', ['title' => '注册已关闭'], false);
        return;
    }

    $err = '';
    if (is_post()) {
        csrf_check();
        $username = post('username');
        $pwd = post('password');
        $pwd2 = post('password2');
        $display = post('display_name');

        // 先按 IP 计一次尝试：失败也计数，防止拿注册接口当用户名探测器
        $attemptLimit = max(10, register_limit() * 3);
        if (!throttle_hit('register', $attemptLimit, 3600)) {
            $err = '这一小时内注册尝试过多，请稍后再来';
        } elseif (!captcha_check(post('captcha'))) {
            $err = '验证码不对，请重新计算';
        } elseif (throttle_count('register_ok', 3600, true) >= register_hourly_cap()) {
            $err = '本站本小时注册人数已达上限，请稍后再试';
        } elseif (!preg_match('/^[A-Za-z0-9_.@-]{3,32}$/', $username)) {
            $err = '账号只能用字母、数字和 _ . @ -，长度 3~32';
        } elseif (one('SELECT id FROM ' . tbl('users') . ' WHERE username = ?', [$username])) {
            $err = '这个账号已经被占用，换一个';
        } elseif (mb_strlen($pwd) < 8) {
            $err = '密码至少 8 位';
        } elseif (preg_match('/^\d+$/', $pwd)) {
            $err = '密码不能全是数字';
        } elseif (strcasecmp($pwd, $username) === 0) {
            $err = '密码不能和账号相同';
        } elseif ($pwd !== $pwd2) {
            $err = '两次输入的密码不一致';
        } else {
            $uid = create_user($username, $pwd, $display !== '' ? $display : $username, 'user');
            $space = create_user_space($uid, $username, $display);
            throttle_hit('register_ok', 1000000, 3600, true);
            audit('register', 'user=' . $username . ' space=' . $space['id']);

            // 注册完直接进入，不用再输一遍密码
            session_regenerate_id(true);
            $_SESSION['uid'] = $uid;
            update_row('users', $uid, ['last_login_at' => now_str()]);
            flash('已为你创建私有空间「' . $space['name'] . '」，这里的内容只有你自己能看到');
            redirect(u());
        }
    }

    view('register', [
        'title'    => '注册',
        'err'      => $err,
        'question' => captcha_new(),
        'limit'    => register_limit(),
    ], false);
}

/* ---------------- 前台 ---------------- */

function ctrl_home(): void
{
    $u = require_login();
    $groups = visible_groups((int)$u['id']);
    $ids = array_map(fn($g) => (int)$g['id'], $groups);
    $stats = group_stats($ids);
    $recent = recent_entries($ids, 8);
    $totalQa = 0;
    $totalDoc = 0;
    foreach ($stats as $s) {
        $totalQa += $s['qa'] ?? 0;
        $totalDoc += $s['doc'] ?? 0;
    }
    view('home', [
        'title'    => '首页',
        'groups'   => $groups,
        'stats'    => $stats,
        'recent'   => $recent,
        'totalQa'  => $totalQa,
        'totalDoc' => $totalDoc,
    ]);
}

function ctrl_search(): void
{
    $u = require_login();
    $q = get_q('q');
    $kind = in_array(get_q('kind'), ['qa', 'doc'], true) ? get_q('kind') : '';
    $gKey = get_q('g');
    $groups = visible_groups((int)$u['id']);
    $allowed = array_map(fn($g) => (int)$g['id'], $groups);

    $scope = $allowed;
    $scopeName = '';
    if ($gKey !== '') {
        $g = find_group($gKey);
        if ($g && in_array((int)$g['id'], $allowed, true)) {
            $scope = [(int)$g['id']];
            $scopeName = $g['name'];
        }
    }

    $page = max(1, (int)get_q('p', '1'));
    $per = 20;
    $res = ['total' => 0, 'items' => []];
    $pg = paginate(0, $per, 1);
    if ($q !== '') {
        $res = search_entries($q, $scope, $kind, $per, ($page - 1) * $per);
        $pg = paginate($res['total'], $per, $page);
        if ($pg['page'] !== $page) {
            $res = search_entries($q, $scope, $kind, $per, $pg['offset']);
        }
    }
    view('search', [
        'title' => $q === '' ? '搜索' : $q,
        'q' => $q, 'kind' => $kind, 'groups' => $groups, 'scopeName' => $scopeName,
        'gKey' => $gKey, 'res' => $res, 'pg' => $pg,
    ]);
}

function ctrl_group(): void
{
    $u = require_login();
    $g = find_group(get_q('slug', get_q('id')));
    if (!$g) {
        http_response_code(404);
        exit('分组不存在');
    }
    if (!can_read_group((int)$u['id'], (int)$g['id'])) {
        http_response_code(403);
        exit('无权访问该分组');
    }
    $kind = in_array(get_q('kind'), ['qa', 'doc'], true) ? get_q('kind') : '';
    $page = max(1, (int)get_q('p', '1'));
    $per = 30;
    $where = 'status = 1 AND group_id = ?';
    $p = [(int)$g['id']];
    if ($kind !== '') {
        $where .= ' AND kind = ?';
        $p[] = $kind;
    }
    $total = (int)val('SELECT COUNT(*) FROM ' . tbl('entries') . ' WHERE ' . $where, $p, 0);
    $pg = paginate($total, $per, $page);
    $rows = all('SELECT * FROM ' . tbl('entries') . ' WHERE ' . $where
        . ' ORDER BY updated_at DESC, id DESC LIMIT ' . $per . ' OFFSET ' . $pg['offset'], $p);
    view('group', [
        'title' => $g['name'], 'group' => $g, 'rows' => $rows, 'pg' => $pg, 'kind' => $kind,
        'canWrite' => can_write_group((int)$u['id'], (int)$g['id']),
    ]);
}

function ctrl_entry(): void
{
    $u = require_login();
    $id = (int)get_q('id');
    $e = entry_by_id($id);
    if (!$e || (int)$e['status'] !== 1) {
        http_response_code(404);
        exit('条目不存在');
    }
    if (!can_read_group((int)$u['id'], (int)$e['group_id'])) {
        http_response_code(403);
        exit('无权访问');
    }
    if ($e['kind'] === 'doc') {
        redirect(u('doc', ['id' => $id]));
    }
    $g = group_by_id((int)$e['group_id']);
    view('entry', [
        'title' => $e['title'] ?: mb_substr((string)$e['question'], 0, 40, 'UTF-8'),
        'e' => $e, 'group' => $g,
        'docs' => entry_docs($id),
        'versions' => entry_versions($id),
        'canWrite' => can_write_group((int)$u['id'], (int)$e['group_id']),
    ]);
}

function ctrl_doc(): void
{
    $u = require_login();
    $id = (int)get_q('id');
    $e = entry_by_id($id);
    if (!$e || (int)$e['status'] !== 1) {
        http_response_code(404);
        exit('文档不存在');
    }
    if (!can_read_group((int)$u['id'], (int)$e['group_id'])) {
        http_response_code(403);
        exit('无权访问');
    }
    $g = group_by_id((int)$e['group_id']);
    view('doc', [
        'title' => $e['title'],
        'e' => $e, 'group' => $g, 'items' => doc_entries($id),
        'canWrite' => can_write_group((int)$u['id'], (int)$e['group_id']),
    ]);
}

/* ---------------- 我的 API Key ---------------- */

function ctrl_keys(): void
{
    $u = require_login();
    $uid = (int)$u['id'];

    if (is_post()) {
        csrf_check();
        $action = post('action');
        if ($action === 'create') {
            $gid = (int)post('group_id');
            $perm = group_perm($uid, $gid);
            $wantRead = post('can_read') === '1';
            $wantWrite = post('can_write') === '1';
            if (!$perm['read'] && !$perm['write']) {
                flash('你没有这个分组的权限', 'err');
                redirect(u('keys'));
            }
            // 不允许申请超出自身权限的能力
            $canRead = $wantRead && $perm['read'];
            $canWrite = $wantWrite && $perm['write'];
            if (!$canRead && !$canWrite) {
                flash('请至少选择读或写；写权限需要你先拥有该分组的写权限', 'err');
                redirect(u('keys'));
            }
            $exp = post('expires_at');
            if ($exp !== '' && !preg_match('/^\d{4}-\d{2}-\d{2}$/', $exp)) {
                $exp = '';
            }
            $r = issue_api_key($uid, post('name'), $gid, $canRead, $canWrite, $exp !== '' ? $exp . ' 23:59:59' : null);
            $_SESSION['new_key'] = $r['key'];
            audit('create_api_key', 'id=' . $r['id'] . ' group=' . $gid);
            flash('API Key 已创建，之后随时可以在本页查看完整 Key');
            redirect(u('keys'));
        }
        if ($action === 'revoke') {
            $kid = (int)post('id');
            $row = one('SELECT * FROM ' . tbl('api_keys') . ' WHERE id = ? AND user_id = ?', [$kid, $uid]);
            if ($row) {
                update_row('api_keys', $kid, ['revoked' => 1]);
                audit('revoke_api_key', 'id=' . $kid);
                flash('已吊销');
            }
            redirect(u('keys'));
        }
    }

    $newKey = $_SESSION['new_key'] ?? null;
    unset($_SESSION['new_key']);
    $rows = all('SELECT k.*, g.name AS group_name, g.slug AS group_slug
                 FROM ' . tbl('api_keys') . ' k
                 LEFT JOIN ' . tbl('groups') . ' g ON g.id = k.group_id
                 WHERE k.user_id = ? ORDER BY k.id DESC', [$uid]);
    $groups = visible_groups($uid);
    $perms = [];
    foreach ($groups as $g) {
        $perms[(int)$g['id']] = group_perm($uid, (int)$g['id']);
    }
    // 回显用的脱敏文本；旧版本创建的 Key 只有哈希，key_plain 为空，页面会提示重建
    foreach ($rows as &$r) {
        $plain = secret_decrypt((string)($r['key_plain'] ?? ''));
        $r['key_mask'] = $plain !== '' ? secret_mask($plain) : '';
    }
    unset($r);
    view('keys', [
        'title' => '我的 API Key', 'rows' => $rows, 'groups' => $groups,
        'perms' => $perms, 'newKey' => $newKey,
    ]);
}

/**
 * 取 Key 明文（JSON）。只有创建者本人能取，管理员也不能看别人的 Key——
 * 能看就等于能冒充对方的 Agent，这条边界不能为了省事放开。
 */
function ctrl_key_reveal(): void
{
    header('Cache-Control: no-store, no-cache, must-revalidate');
    $u = require_login();
    $id = (int)get_q('id');

    if (is_post()) {
        csrf_check();
    }

    $row = one('SELECT * FROM ' . tbl('api_keys') . ' WHERE id = ?', [$id]);
    if (!$row) {
        json_out(['ok' => false, 'error' => ['code' => 'not_found', 'message' => 'Key 不存在']], 404);
    }
    if ((int)$row['user_id'] !== (int)$u['id']) {
        json_out(['ok' => false, 'error' => ['code' => 'forbidden', 'message' => '只能查看自己创建的 Key']], 403);
    }
    if ((int)$row['revoked'] === 1) {
        json_out(['ok' => false, 'error' => ['code' => 'revoked', 'message' => '该 Key 已吊销，无法查看']], 403);
    }
    $plain = secret_decrypt((string)($row['key_plain'] ?? ''));
    if ($plain === '') {
        json_out([
            'ok' => false,
            'error' => [
                'code' => 'legacy',
                'message' => '这条 Key 是旧版本创建的，明文没有留存、无法还原。吊销后用新版本重建一个即可长期查看。',
            ],
        ], 404);
    }
    json_out(['ok' => true, 'data' => ['id' => $id, 'key' => $plain, 'mask' => secret_mask($plain)]]);
}

/* ---------------- 后台 ---------------- */

function ctrl_admin(): void
{
    require_admin();
    $counts = [
        'users'   => (int)val('SELECT COUNT(*) FROM ' . tbl('users'), [], 0),
        'groups'  => (int)val('SELECT COUNT(*) FROM ' . tbl('groups'), [], 0),
        'entries' => (int)val('SELECT COUNT(*) FROM ' . tbl('entries') . ' WHERE status = 1', [], 0),
        'keys'    => (int)val('SELECT COUNT(*) FROM ' . tbl('api_keys') . ' WHERE revoked = 0', [], 0),
    ];
    $dbSize = 0;
    if (db_driver() === 'sqlite') {
        $p = cfg()['db']['sqlite_path'];
        $dbSize = is_file($p) ? (int)filesize($p) : 0;
    }
    view('admin_home', [
        'title' => '后台', 'counts' => $counts, 'dbSize' => $dbSize,
        'recentLogs' => all('SELECT * FROM ' . tbl('audit_log') . ' ORDER BY id DESC LIMIT 12'),
    ]);
}

function ctrl_admin_users(): void
{
    require_admin();
    if (is_post()) {
        csrf_check();
        $action = post('action');
        if ($action === 'create') {
            $username = post('username');
            $pwd = post('password');
            if (!preg_match('/^[A-Za-z0-9_.@-]{3,64}$/', $username)) {
                flash('用户名只能用字母数字和 _ . @ -，3~64 位', 'err');
            } elseif (strlen($pwd) < 8) {
                flash('密码至少 8 位', 'err');
            } elseif (one('SELECT id FROM ' . tbl('users') . ' WHERE username = ?', [$username])) {
                flash('用户名已存在', 'err');
            } else {
                $id = create_user($username, $pwd, post('display_name') ?: $username, 'user');
                audit('create_user', $username);
                flash('用户已创建，请到「分组授权」给他分配权限');
                redirect(u('admin_perm', ['uid' => $id]));
            }
        }
        if ($action === 'reset') {
            $id = (int)post('id');
            $pwd = post('password');
            if (strlen($pwd) < 8) {
                flash('密码至少 8 位', 'err');
            } else {
                update_row('users', $id, ['password_hash' => password_hash($pwd, PASSWORD_DEFAULT)]);
                audit('reset_password', 'user=' . $id);
                flash('密码已重置');
            }
        }
        if ($action === 'toggle') {
            $id = (int)post('id');
            $row = one('SELECT * FROM ' . tbl('users') . ' WHERE id = ?', [$id]);
            if ($row) {
                if ((int)$row['id'] === (int)current_user()['id']) {
                    flash('不能停用自己', 'err');
                } else {
                    update_row('users', $id, ['status' => (int)$row['status'] === 1 ? 0 : 1]);
                    flash('状态已切换');
                }
            }
        }
        if ($action === 'delete') {
            $id = (int)post('id');
            if ($id === (int)current_user()['id']) {
                flash('不能删除自己', 'err');
            } else {
                // 私有空间不跟着账号一起消失：转为共享分组，内容留给管理员处置
                $spaces = all('SELECT name FROM ' . tbl('groups') . ' WHERE owner_id = ?', [$id]);
                q('UPDATE ' . tbl('groups') . ' SET owner_id = 0 WHERE owner_id = ?', [$id]);
                q('DELETE FROM ' . tbl('group_user') . ' WHERE user_id = ?', [$id]);
                q('UPDATE ' . tbl('api_keys') . ' SET revoked = 1 WHERE user_id = ?', [$id]);
                q('DELETE FROM ' . tbl('users') . ' WHERE id = ?', [$id]);
                audit('delete_user', 'user=' . $id . ' spaces=' . count($spaces));
                flash(count($spaces) > 0
                    ? '用户已删除；其 ' . count($spaces) . ' 个私有空间已转为共享分组，内容保留在「分组管理」里'
                    : '用户已删除');
            }
        }
        redirect(u('admin_users'));
    }
    $rows = all('SELECT u.*,
                        (SELECT COUNT(*) FROM ' . tbl('groups') . ' g WHERE g.owner_id = u.id) AS spaces
                 FROM ' . tbl('users') . ' u ORDER BY u.role, u.id');
    view('admin_users', ['title' => '用户管理', 'rows' => $rows]);
}

function ctrl_admin_perm(): void
{
    require_admin();
    $uid = (int)get_q('uid', '0');
    $user = one('SELECT * FROM ' . tbl('users') . ' WHERE id = ?', [$uid]);
    if (!$user) {
        $list = all('SELECT * FROM ' . tbl('users') . ' ORDER BY role, id');
        view('admin_perm_pick', ['title' => '分组授权', 'rows' => $list]);
        return;
    }
    $allGroups = all('SELECT g.*, u.username AS owner_name
                      FROM ' . tbl('groups') . ' g
                      LEFT JOIN ' . tbl('users') . ' u ON u.id = g.owner_id
                      ORDER BY g.sort, g.id');
    // 私有空间不参与授权：只有归属人自己能进，管理员也不能把人塞进去
    $groups = array_values(array_filter($allGroups, fn($g) => !is_private_group($g)));
    $privateSpaces = array_values(array_filter($allGroups, fn($g) => is_private_group($g)));
    if (is_post()) {
        csrf_check();
        $read = (array)($_POST['read'] ?? []);
        $write = (array)($_POST['write'] ?? []);
        // 只重建「公共分组」的授权，私有空间原有的成员关系保持不动
        $privateIds = array_map(fn($g) => (int)$g['id'], $privateSpaces);
        if ($privateIds) {
            $in = implode(',', array_fill(0, count($privateIds), '?'));
            q('DELETE FROM ' . tbl('group_user') . ' WHERE user_id = ? AND group_id NOT IN (' . $in . ')',
                array_merge([$uid], $privateIds));
        } else {
            q('DELETE FROM ' . tbl('group_user') . ' WHERE user_id = ?', [$uid]);
        }
        foreach ($groups as $g) {
            $gid = (int)$g['id'];
            $r = in_array((string)$gid, array_map('strval', $read), true) ? 1 : 0;
            $w = in_array((string)$gid, array_map('strval', $write), true) ? 1 : 0;
            if ($r || $w) {
                insert_row('group_user', [
                    'group_id' => $gid, 'user_id' => $uid,
                    'can_read' => $r ? 1 : 0, 'can_write' => $w ? 1 : 0,
                    'created_at' => now_str(),
                ]);
            }
        }
        audit('set_group_perms', 'user=' . $uid);
        flash('权限已保存');
        redirect(u('admin_perm', ['uid' => $uid]));
    }
    $perms = user_perms($uid);
    view('admin_perm', [
        'title' => '分组授权 · ' . $user['username'], 'user' => $user,
        'groups' => $groups, 'perms' => $perms, 'privateSpaces' => $privateSpaces,
    ]);
}

function ctrl_admin_groups(): void
{
    require_admin();
    if (is_post()) {
        csrf_check();
        $action = post('action');
        if ($action === 'create' || $action === 'update') {
            $name = post('name');
            if ($name === '') {
                flash('分组名称不能为空', 'err');
            } else {
                $data = [
                    'name' => mb_substr($name, 0, 100, 'UTF-8'),
                    'description' => mb_substr(post('description'), 0, 480, 'UTF-8'),
                    'sort' => (int)post('sort', '0'),
                ];
                if ($action === 'create') {
                    $data['slug'] = make_slug($name);
                    $data['created_at'] = now_str();
                    insert_row('groups', $data);
                    audit('create_group', $name);
                    flash('分组已创建，记得给用户授权');
                    redirect(u('admin_groups'));
                } else {
                    $id = (int)post('id');
                    $slugIn = post('slug');
                    if ($slugIn !== '') {
                        $data['slug'] = make_slug($slugIn, $id);
                    }
                    update_row('groups', $id, $data);
                    audit('update_group', $name);
                    flash('分组已更新');
                }
            }
        }
        if ($action === 'delete') {
            $id = (int)post('id');
            $n = (int)val('SELECT COUNT(*) FROM ' . tbl('entries') . ' WHERE group_id = ?', [$id], 0);
            if ($n > 0) {
                flash('该分组下还有 ' . $n . ' 条内容，请先清空或转移', 'err');
            } else {
                q('DELETE FROM ' . tbl('group_user') . ' WHERE group_id = ?', [$id]);
                q('DELETE FROM ' . tbl('groups') . ' WHERE id = ?', [$id]);
                audit('delete_group', 'group=' . $id);
                flash('分组已删除');
            }
        }
        redirect(u('admin_groups'));
    }
    $rows = all('SELECT g.*, u.username AS owner_name,
                        (SELECT COUNT(*) FROM ' . tbl('entries') . ' e WHERE e.group_id = g.id AND e.status = 1) AS cnt
                 FROM ' . tbl('groups') . ' g
                 LEFT JOIN ' . tbl('users') . ' u ON u.id = g.owner_id
                 ORDER BY g.sort, g.id');
    view('admin_groups', ['title' => '分组管理', 'rows' => $rows]);
}

function ctrl_admin_keys(): void
{
    require_admin();
    if (is_post()) {
        csrf_check();
        $kid = (int)post('id');
        $row = one('SELECT * FROM ' . tbl('api_keys') . ' WHERE id = ?', [$kid]);
        if ($row) {
            update_row('api_keys', $kid, ['revoked' => (int)$row['revoked'] === 1 ? 0 : 1]);
            audit('admin_toggle_key', 'id=' . $kid);
            flash('状态已切换');
        }
        redirect(u('admin_keys'));
    }
    $rows = all('SELECT k.*, u.username, g.name AS group_name
                 FROM ' . tbl('api_keys') . ' k
                 LEFT JOIN ' . tbl('users') . ' u ON u.id = k.user_id
                 LEFT JOIN ' . tbl('groups') . ' g ON g.id = k.group_id
                 ORDER BY k.id DESC');
    view('admin_keys', ['title' => 'API Key 总览', 'rows' => $rows]);
}

/* ---------------- 内容管理（超管） ---------------- */

function ctrl_admin_content(): void
{
    $u = require_admin();
    $gid = (int)get_q('gid', '0');
    $groups = all('SELECT * FROM ' . tbl('groups') . ' ORDER BY sort, id');
    if (!$groups) {
        view('admin_content', ['title' => '内容管理', 'groups' => [], 'group' => null, 'rows' => [], 'pg' => paginate(0, 20, 1), 'kind' => '']);
        return;
    }
    if ($gid <= 0) {
        $gid = (int)$groups[0]['id'];
    }
    $group = group_by_id($gid);
    $kind = in_array(get_q('kind'), ['qa', 'doc'], true) ? get_q('kind') : '';
    $q = get_q('q');
    $where = 'group_id = ? AND status = 1';
    $p = [$gid];
    if ($kind !== '') {
        $where .= ' AND kind = ?';
        $p[] = $kind;
    }
    if ($q !== '') {
        $where .= ' AND (title LIKE ? OR question LIKE ?)';
        $p[] = '%' . $q . '%';
        $p[] = '%' . $q . '%';
    }
    $page = max(1, (int)get_q('p', '1'));
    $per = 20;
    $total = (int)val('SELECT COUNT(*) FROM ' . tbl('entries') . ' WHERE ' . $where, $p, 0);
    $pg = paginate($total, $per, $page);
    $rows = all('SELECT * FROM ' . tbl('entries') . ' WHERE ' . $where
        . ' ORDER BY updated_at DESC, id DESC LIMIT ' . $per . ' OFFSET ' . $pg['offset'], $p);
    view('admin_content', [
        'title' => '内容管理', 'groups' => $groups, 'group' => $group,
        'rows' => $rows, 'pg' => $pg, 'kind' => $kind, 'q' => $q,
    ]);
}

function ctrl_entry_edit(): void
{
    $u = require_login();
    $id = (int)get_q('id', '0');
    $gid = (int)get_q('gid', '0');
    $e = $id > 0 ? entry_by_id($id) : null;
    if ($e) {
        $gid = (int)$e['group_id'];
    }
    $group = group_by_id($gid);
    if (!$group) {
        flash('请先选择分组', 'err');
        redirect(is_admin($u) ? u('admin_content') : u());
    }
    // 管理员，或对该分组有写权限的人
    if (!is_admin($u) && !can_write_group((int)$u['id'], $gid)) {
        http_response_code(403);
        exit('403 没有该分组的写权限');
    }

    if (is_post()) {
        csrf_check();
        $action = post('action', 'save');
        if ($action === 'delete' && $e) {
            soft_delete_entry((int)$e['id']);
            audit('delete_entry', 'id=' . $e['id']);
            flash('已删除');
            redirect(is_admin($u) ? u('admin_content', ['gid' => $gid]) : u('g', ['slug' => $group['slug']]));
        }
        $data = [
            'group_id' => $gid,
            'kind' => post('kind', 'qa'),
            'title' => post('title'),
            'question' => post('question'),
            'body' => (string)($_POST['body'] ?? ''),
            'source' => post('source'),
            'source_date' => post('source_date'),
        ];
        if ($data['title'] === '' && $data['question'] === '' && trim($data['body']) === '') {
            flash('标题、问题、内容至少填一项', 'err');
        } else {
            $newId = save_entry($data, $e ? (int)$e['id'] : null);
            if ($data['kind'] === 'doc') {
                $ids = array_filter(array_map('intval', (array)($_POST['links'] ?? [])));
                save_doc_links($newId, $ids);
            }
            audit($e ? 'update_entry' : 'create_entry', 'id=' . $newId);
            flash('已保存');
            redirect(u('entry_edit', ['id' => $newId]));
        }
    }

    $links = $e && $e['kind'] === 'doc' ? array_map(fn($r) => (int)$r['id'], doc_entries((int)$e['id'])) : [];
    $qaList = $e && $e['kind'] === 'doc'
        ? all('SELECT id, question, title FROM ' . tbl('entries') . ' WHERE group_id = ? AND kind = ? AND status = 1 ORDER BY updated_at DESC LIMIT 500', [$gid, 'qa'])
        : [];
    view('admin_entry_edit', [
        'title' => $e ? '编辑条目' : '新建条目',
        'e' => $e, 'group' => $group, 'links' => $links, 'qaList' => $qaList,
    ]);
}

/* ---------------- 系统与升级 ---------------- */

function ctrl_admin_system(): void
{
    require_admin();
    $msg = '';
    $err = '';
    if (is_post()) {
        csrf_check();
        if (($_POST['action'] ?? '') === 'settings') {
            setting_set('allow_register', post('allow_register') === '1' ? '1' : '0');
            $n = (int)post('register_per_hour', '5');
            setting_set('register_per_hour', (string)max(1, min(100, $n)));
            $site = post('site_name');
            if ($site !== '') {
                setting_set('site_name', mb_substr($site, 0, 60, 'UTF-8'));
            }
            audit('update_settings', 'allow_register=' . setting_get('allow_register') . ' per_hour=' . setting_get('register_per_hour'));
            flash('设置已保存');
            redirect(u('admin_system'));
        }
        if (($_POST['action'] ?? '') === 'upgrade') {
            $f = $_FILES['package'] ?? null;
            if (!$f || ($f['error'] ?? 1) !== UPLOAD_ERR_OK) {
                $err = '没有收到上传文件，或上传失败（检查 php.ini 的 upload_max_filesize）';
            } elseif (strtolower(pathinfo((string)$f['name'], PATHINFO_EXTENSION)) !== 'zip') {
                $err = '更新包必须是 .zip';
            } else {
                $r = upgrade_apply((string)$f['tmp_name']);
                if ($r['ok']) {
                    $msg = $r['message'];
                } else {
                    $err = $r['message'];
                }
            }
        }
    }
    $verJson = json_decode((string)@file_get_contents(BASE_PATH . '/version.json'), true) ?: [];
    view('admin_system', [
        'title' => '系统与升级',
        'ver' => $verJson,
        'msg' => $msg, 'err' => $err,
        'history' => all('SELECT * FROM ' . tbl('audit_log') . " WHERE action LIKE 'upgrade%' ORDER BY id DESC LIMIT 10"),
        'php' => PHP_VERSION,
        'driver' => db_driver(),
        'allowRegister' => register_allowed(),
        'perHour' => register_limit(),
        'userCount' => (int)val('SELECT COUNT(*) FROM ' . tbl('users'), [], 0),
        'spaceCount' => (int)val('SELECT COUNT(*) FROM ' . tbl('groups') . ' WHERE owner_id > 0', [], 0),
    ]);
}

/* ---------------- 数据导入 ---------------- */

function ctrl_admin_import(): void
{
    require_admin();
    $msg = '';
    $err = '';
    $stats = null;
    $builtin = BASE_PATH . '/data/wayfair-qa.csv';

    if (is_post()) {
        csrf_check();
        $mode = post('mode', 'builtin');
        $groupName = post('group_name', '跨境电商');
        $username = post('username');
        $source = post('source', '微信群 · Wayfair破浪远洋3群');
        $csv = '';

        if ($mode === 'builtin') {
            if (!is_file($builtin)) {
                $err = '内置数据文件不存在（data/wayfair-qa.csv）';
            } else {
                $csv = $builtin;
            }
        } else {
            $f = $_FILES['csv'] ?? null;
            if (!$f || ($f['error'] ?? 1) !== UPLOAD_ERR_OK) {
                $err = '没有收到文件，或上传失败（检查 upload_max_filesize）';
            } else {
                $ext = strtolower(pathinfo((string)$f['name'], PATHINFO_EXTENSION));
                if (!in_array($ext, ['csv', 'txt'], true)) {
                    $err = '只支持 .csv 文件';
                } else {
                    $tmp = BASE_PATH . '/storage/tmp/import-' . bin2hex(random_bytes(4)) . '.csv';
                    if (!move_uploaded_file((string)$f['tmp_name'], $tmp)) {
                        $err = '文件保存失败，检查 storage/tmp 权限';
                    } else {
                        $csv = $tmp;
                    }
                }
            }
        }

        if ($err === '' && $csv !== '') {
            try {
                [$group, $user] = ensure_group_and_perm($groupName !== '' ? $groupName : '跨境电商', $username);
                $stats = import_csv($csv, (int)$group['id'], (int)$user['id'], $source);
                audit('import_csv', "group={$group['id']} inserted={$stats['inserted']}");
                $msg = "导入完成：新增 {$stats['inserted']} 条，跳过 {$stats['skipped']} 条";
                if ($csv !== $builtin) {
                    @unlink($csv);
                }
            } catch (Throwable $e) {
                $err = '导入失败：' . $e->getMessage();
            }
        }
    }

    view('admin_import', [
        'title' => '导入数据',
        'msg' => $msg,
        'err' => $err,
        'stats' => $stats,
        'builtin' => is_file($builtin),
        'builtinSize' => is_file($builtin) ? round(filesize($builtin) / 1048576, 1) : 0,
        'users' => all('SELECT id, username, display_name FROM ' . tbl('users') . ' WHERE status = 1 ORDER BY role, id'),
        'groups' => all('SELECT id, name FROM ' . tbl('groups') . ' ORDER BY sort, id'),
    ]);
}

/* ---------------- 用户自建分组 ---------------- */

function ctrl_group_new(): void
{
    $u = require_login();
    if (is_post()) {
        csrf_check();
        $name = post('name');
        $desc = post('description');
        if ($name === '') {
            flash('分组名称不能为空', 'err');
        } else {
            $gid = insert_row('groups', [
                'name' => mb_substr($name, 0, 100, 'UTF-8'),
                'slug' => make_slug($name),
                'description' => mb_substr($desc, 0, 480, 'UTF-8'),
                'owner_id' => (int)$u['id'],
                'sort' => 50,
                'created_at' => now_str(),
            ]);
            // 创建者自动获得读写权限；owner_id already 标记了归属，别人不会被授权进来
            insert_row('group_user', [
                'group_id' => $gid,
                'user_id' => (int)$u['id'],
                'can_read' => 1,
                'can_write' => 1,
                'created_at' => now_str(),
            ]);
            audit('create_group_by_user', 'id=' . $gid . ' ' . $name);
            flash('分组已创建。它是你的私有空间，只有你能访问');
            $g = group_by_id($gid);
            redirect(u('g', ['slug' => $g['slug']]));
        }
    }
    view('group_new', ['title' => '新建分组']);
}
