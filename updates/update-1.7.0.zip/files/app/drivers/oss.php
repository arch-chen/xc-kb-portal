<?php
declare(strict_types=1);

/**
 * 阿里云 OSS（V1 签名）。
 * OSS 至今仍接受 V1：Authorization: OSS {AK}:{base64(hmac-sha1(SK, sts))}
 * 不引 SDK，只用到 PUT / GET / DELETE 三个动作。
 */
class StorageOss extends StorageDriver
{
    public function label(): string
    {
        return '阿里云 OSS';
    }

    protected function host(): string
    {
        $bucket = $this->need('bucket', 'Bucket');
        $ep = $this->need('endpoint', 'Endpoint');
        $ep = preg_replace('#^https?://#i', '', $ep) ?? $ep;
        $ep = rtrim($ep, '/');
        // 允许直接填 bucket.oss-cn-xxx.aliyuncs.com
        if (str_starts_with($ep, $bucket . '.')) {
            return $ep;
        }
        return $bucket . '.' . $ep;
    }

    protected function sign(string $method, string $key, string $contentType = ''): array
    {
        $ak = $this->need('ak', 'AccessKey ID');
        $sk = $this->need('sk', 'AccessKey Secret');
        $bucket = $this->need('bucket', 'Bucket');
        $date = gmdate('D, d M Y H:i:s \G\M\T');
        $resource = '/' . $bucket . '/' . ltrim($key, '/');
        if ($key === '' && $method === 'GET') {
            $resource = '/' . $bucket . '/';
        }
        $sts = $method . "\n\n" . $contentType . "\n" . $date . "\n" . $resource;
        $sig = base64_encode(hash_hmac('sha1', $sts, $sk, true));
        return [
            'Date: ' . $date,
            'Authorization: OSS ' . $ak . ':' . $sig,
        ];
    }

    protected function urlFor(string $key): string
    {
        return 'https://' . $this->host() . '/' . ltrim($key, '/');
    }

    public function put(string $key, string $file, string $mime): void
    {
        $body = (string)@file_get_contents($file);
        if ($body === '' && filesize($file) > 0) {
            throw new RuntimeException('读取本地文件失败');
        }
        $h = $this->sign('PUT', $key, $mime);
        $h[] = 'Content-Type: ' . $mime;
        $h[] = 'Content-Length: ' . strlen($body);
        $res = $this->http('PUT', $this->urlFor($key), $h, $body);
        $this->expect($res, '上传');
    }

    public function fetch(string $key, string $dest): void
    {
        $res = $this->http('GET', $this->urlFor($key), $this->sign('GET', $key));
        $this->expect($res, '下载');
        if (@file_put_contents($dest, $res['body']) === false) {
            throw new RuntimeException('写入临时文件失败');
        }
    }

    public function drop(string $key): void
    {
        $res = $this->http('DELETE', $this->urlFor($key), $this->sign('DELETE', $key));
        if ($res['code'] === 404) {
            return;
        }
        $this->expect($res, '删除');
    }

    public function probe(): string
    {
        $key = '.probe/' . bin2hex(random_bytes(6)) . '.txt';
        $tmp = tempnam(sys_get_temp_dir(), 'kboss');
        @file_put_contents($tmp, 'ok');
        try {
            $this->put($key, $tmp, 'text/plain');
            $this->drop($key);
        } finally {
            @unlink($tmp);
        }
        return '上传/删除正常：' . $this->host();
    }
}
