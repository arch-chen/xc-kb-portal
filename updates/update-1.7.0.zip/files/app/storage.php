<?php
declare(strict_types=1);

/**
 * 存储驱动层。
 *
 * 一个平台 = storage_providers 一行；驱动只负责「把这段字节放到那边 / 取回来 / 删掉」，
 * 不掺业务逻辑。多副本、灾备同步、权限都在 app/files.php 里。
 *
 * 约束：零依赖。5 个云平台的签名全部手写，不用 SDK。
 */

abstract class StorageDriver
{
    protected array $cfg;

    public function __construct(array $cfg)
    {
        $this->cfg = $cfg;
    }

    /** 上传本地文件到 $key */
    abstract public function put(string $key, string $file, string $mime): void;

    /** 下载 $key 到本地 $dest（失败抛异常） */
    abstract public function fetch(string $key, string $dest): void;

    /** 删除 $key（不存在也算成功） */
    abstract public function drop(string $key): void;

    /** 连通性测试：成功返回一句人话，失败抛异常 */
    abstract public function probe(): string;

    /** 驱动显示名 */
    abstract public function label(): string;

    protected function opt(string $k, string $d = ''): string
    {
        $v = $this->cfg[$k] ?? $d;
        return is_scalar($v) ? trim((string)$v) : $d;
    }

    protected function need(string $k, string $label): string
    {
        $v = $this->opt($k);
        if ($v === '') {
            throw new RuntimeException('缺少配置项：' . $label);
        }
        return $v;
    }

    /**
     * 通用 HTTP 请求（curl）。
     * $body 为 null 表示无请求体；返回 ['code'=>int, 'body'=>string]。
     * 大文件走内存，所以上传上限要卡在 settings 的 file_max_mb 上，默认 20MB。
     */
    protected function http(string $method, string $url, array $headers = [], ?string $body = null, int $timeout = 60): array
    {
        $ch = curl_init($url);
        $opts = [
            CURLOPT_CUSTOMREQUEST  => $method,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => false,
            CURLOPT_CONNECTTIMEOUT => 10,
            CURLOPT_TIMEOUT        => $timeout,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
            CURLOPT_HTTPHEADER     => $headers,
            CURLOPT_USERAGENT      => 'kb-portal/1.7 (+php)',
        ];
        if ($body !== null) {
            $opts[CURLOPT_POSTFIELDS] = $body;
        }
        if (defined('CURLOPT_PROTOCOLS')) {
            $opts[CURLOPT_PROTOCOLS] = CURLPROTO_HTTPS | CURLPROTO_HTTP;
        }
        curl_setopt_array($ch, $opts);

        $resp = curl_exec($ch);
        $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $err = curl_error($ch);
        curl_close($ch);

        if ($resp === false) {
            throw new RuntimeException('网络请求失败：' . ($err !== '' ? $err : '未知错误'));
        }
        return ['code' => $code, 'body' => (string)$resp];
    }

    /** 统一把非 2xx 转成异常，消息带上响应体前 200 字（云端报错通常就在里面） */
    protected function expect(array $res, string $what): string
    {
        if ($res['code'] >= 200 && $res['code'] < 300) {
            return $res['body'];
        }
        $msg = trim(preg_replace('/\s+/u', ' ', mb_substr($res['body'], 0, 200)) ?? '');
        throw new RuntimeException($what . '失败（HTTP ' . $res['code'] . '）' . ($msg !== '' ? '：' . $msg : ''));
    }
}

/** 支持的驱动清单（后台下拉框直接用这个） */
function storage_driver_labels(): array
{
    return [
        'local' => '本地磁盘',
        'oss'   => '阿里云 OSS',
        'cos'   => '腾讯云 COS',
        'qiniu' => '七牛云',
        'upyun' => '又拍云',
        'r2'    => 'Cloudflare R2（S3 兼容）',
    ];
}

/** 各驱动需要的配置字段（后台表单按这个渲染，密钥类字段加密存） */
function storage_driver_fields(string $driver): array
{
    $map = [
        'local' => [
            'root' => ['本地目录', '相对站点根目录，默认 storage/uploads', 'storage/uploads', false],
        ],
        'oss' => [
            'endpoint' => ['Endpoint', '如 oss-cn-hangzhou.aliyuncs.com（不带 bucket）', 'oss-cn-hangzhou.aliyuncs.com', false],
            'bucket'   => ['Bucket', '存储桶名', '', false],
            'ak'       => ['AccessKey ID', '', '', false],
            'sk'       => ['AccessKey Secret', '加密保存，页面不回显', '', true],
            'domain'   => ['自定义域名（可选）', '如 cdn.example.com，填了下载走它', '', false],
        ],
        'cos' => [
            'region' => ['Region', '如 ap-guangzhou', 'ap-guangzhou', false],
            'bucket' => ['Bucket', '形如 kb-1250000000（带 APPID）', '', false],
            'ak'     => ['SecretId', '', '', false],
            'sk'     => ['SecretKey', '加密保存', '', true],
            'domain' => ['自定义域名（可选）', '', '', false],
        ],
        'qiniu' => [
            'bucket' => ['Bucket', '空间名', '', false],
            'ak'     => ['AccessKey', '', '', false],
            'sk'     => ['SecretKey', '加密保存', '', true],
            'domain' => ['绑定域名', '必填，私有空间下载要用它拼 URL', '', false],
            'host'   => ['上传加速域名（可选）', '默认 up.qiniup.com', 'up.qiniup.com', false],
        ],
        'upyun' => [
            'bucket'   => ['空间名', '', '', false],
            'operator' => ['操作员', '', '', false],
            'password' => ['操作员密码', '加密保存', '', true],
            'domain'   => ['绑定域名（可选）', '', '', false],
        ],
        'r2' => [
            'account' => ['Account ID', 'Cloudflare 后台的账户 ID（自建 MinIO 可随意填）', '', false],
            'bucket'  => ['Bucket', '', '', false],
            'ak'      => ['Access Key ID', '', '', false],
            'sk'      => ['Secret Access Key', '加密保存', '', true],
            'endpoint' => ['自定义 Endpoint（可选）', '如 https://minio.example.com 或 http://127.0.0.1:9000；留空走 Cloudflare', '', false],
            'domain'  => ['公开域名（可选）', '如 pub-xxx.r2.dev，仅公开桶可用', '', false],
        ],
    ];
    return $map[$driver] ?? [];
}

/** 解密平台配置（库里存的是 secret_encrypt 后的 JSON） */
function provider_config(array $p): array
{
    $raw = (string)($p['config'] ?? '');
    if ($raw === '') {
        return [];
    }
    $plain = $raw;
    if (function_exists('secret_decrypt') && str_starts_with($raw, 'g1:')) {
        $plain = secret_decrypt($raw);
    }
    $d = json_decode($plain, true);
    return is_array($d) ? $d : [];
}

/** 按平台行实例化驱动 */
function provider_driver(array $p): StorageDriver
{
    $cls = 'Storage' . ucfirst((string)$p['driver']);
    if (!class_exists($cls)) {
        throw new RuntimeException('不支持的驱动：' . (string)$p['driver']);
    }
    /** @var StorageDriver $d */
    $d = new $cls(provider_config($p));
    return $d;
}

/** 启用的平台，主平台排最前 */
function storage_providers(bool $onlyEnabled = false): array
{
    $sql = 'SELECT * FROM ' . tbl('storage_providers');
    if ($onlyEnabled) {
        $sql .= ' WHERE enabled = 1';
    }
    $sql .= ' ORDER BY is_primary DESC, sort, id';
    return all($sql);
}

/** 新文件默认写到这个平台 */
function storage_primary(): ?array
{
    $p = one('SELECT * FROM ' . tbl('storage_providers') . ' WHERE enabled = 1 ORDER BY is_primary DESC, sort, id LIMIT 1');
    return $p ?: null;
}

function provider_by_id(int $id): ?array
{
    return one('SELECT * FROM ' . tbl('storage_providers') . ' WHERE id = ?', [$id]);
}

/** 上传限额（MB） */
function file_max_mb(): int
{
    $mb = (int)setting_get('file_max_mb', '20');
    return $mb > 0 ? min($mb, 200) : 20;
}

/** 允许的扩展名。刻意不含 svg（可内嵌脚本）、html、php、js 这类可执行/可提权格式 */
function file_allowed_ext(): array
{
    return [
        'jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp', 'ico',
        'pdf', 'txt', 'md', 'csv',
        'doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx',
        'zip', 'rar', '7z',
        'mp4', 'mov', 'mp3', 'wav',
    ];
}

/** 按扩展名给个保守的 Content-Type（下载时用，避免内容嗅探） */
function file_mime_by_ext(string $ext): string
{
    $map = [
        'jpg' => 'image/jpeg', 'jpeg' => 'image/jpeg', 'png' => 'image/png', 'gif' => 'image/gif',
        'webp' => 'image/webp', 'bmp' => 'image/bmp', 'ico' => 'image/x-icon',
        'pdf' => 'application/pdf',
        'txt' => 'text/plain; charset=utf-8', 'md' => 'text/plain; charset=utf-8', 'csv' => 'text/csv; charset=utf-8',
        'doc' => 'application/msword',
        'docx' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'xls' => 'application/vnd.ms-excel',
        'xlsx' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        'ppt' => 'application/vnd.ms-powerpoint',
        'pptx' => 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
        'zip' => 'application/zip', 'rar' => 'application/vnd.rar', '7z' => 'application/x-7z-compressed',
        'mp4' => 'video/mp4', 'mov' => 'video/quicktime', 'mp3' => 'audio/mpeg', 'wav' => 'audio/wav',
    ];
    return $map[$ext] ?? 'application/octet-stream';
}

/** 这些扩展名在浏览器里可以直接看，其余强制下载 */
function file_inline_ext(): array
{
    return ['jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp', 'ico', 'pdf', 'txt', 'md', 'mp4', 'mov', 'mp3', 'wav'];
}

// 驱动实现（一个平台一个文件，放在 app/drivers/）
foreach (glob(__DIR__ . '/drivers/*.php') ?: [] as $__drv) {
    require_once $__drv;
}
unset($__drv);
