# 部署手册 · 知识库门户（kb-portal）

这份文档是**安装和上线时照着做**的清单，不是功能说明（功能见 `README.md`，接口见站内 `?r=docs`）。

先说最要命的一条：**只把文件传上去、跑完安装向导，站点就能用，但数据是裸奔的。**
`storage/kb.sqlite` 里是全部问答、账号、邮箱、审计日志，nginx 会把它当静态文件直接发出去——
不需要账号、不需要 API Key，一条 URL 就能下载整库。所以第 4 章那两行 nginx 规则**不是优化项，是验收项**。

---

## 1. 30 秒清单

| # | 做什么 | 漏了会怎样 |
|---|---|---|
| 1 | PHP 8.0+，装 `pdo_sqlite`（或 `pdo_mysql`）、`mbstring`、`openssl`、`zip` | 安装页红项 / 后台上传更新包解压失败 |
| 2 | 把全量包解压到站点根目录，`storage/` 归 www 用户可写 | 安装时报 `unable to open database file` |
| 3 | 浏览器打开 `/install.php` 走完向导 | — |
| 4 | **删掉 `install.php`** | 多一个暴露面（虽然上锁了） |
| 5 | **在站点配置里加两条 nginx 规则**（见第 4 章） | **整库可被直接下载** |
| 6 | 按第 5 章自检 5 条，全过才算上线 | 出问题时不知道哪一步错 |
| 7 | 备份 `storage/kb.sqlite` **和** `config.php` | 换服务器时数据在、Key 解不开 |

---

## 2. 环境要求

| 项 | 要求 | 说明 |
|---|---|---|
| PHP | 8.0 及以上（推荐 8.1 / 8.2） | 用了 `str_contains`、`declare(strict_types=1)` 等 8.0 特性 |
| 扩展 | `pdo` + `pdo_sqlite`（或 `pdo_mysql`）、`mbstring`、`openssl`、`zip` | `zip` 只影响后台在线升级；`openssl` 影响邮件与 Key 加密 |
| 数据库 | SQLite（默认，零配置）或 MySQL 5.7+ / MariaDB 10.3+ | SQLite 文件建议留在 `storage/`，该目录已默认禁止访问 |
| Web 服务器 | nginx 或 Apache | Apache 有内置 `.htaccess` 兜底；**nginx 必须手动加规则** |
| 磁盘 | 100 MB 起 | 库随问答量增长，1 万条问答约 5–10 MB |
| HTTPS | 强烈建议 | 会话 Cookie 会自动带 `Secure`，纯 HTTP 下登录会反复掉 |

宝塔里确认扩展的位置：**软件商店 → PHP 8.x → 设置 → 安装扩展**。

---

## 3. 上传与安装

1. **传文件**：把 `kb-portal-x.y.z.zip` 解压到站点根目录（如 `/www/wwwroot/dos.example.com`），
   不是子目录。若必须放子目录（`/kb/`），伪静态前缀和 `config.php` 里的地址都要跟着改，不推荐。
2. **给权限**（宝塔用户默认是 `www`）：
   ```bash
   cd /www/wwwroot/你的站点目录
   chown -R www:www .
   chmod -R 775 storage
   ```
   根目录也需要可写——安装向导要生成 `config.php`。
3. **跑安装向导**：浏览器打开 `https://你的域名/install.php`。
   页面顶部会先做环境自检，红项解决完再填表。
4. **填表**：站点名称、数据库（默认 SQLite，路径保持 `storage/kb.sqlite` 即可）、管理员账号密码（≥8 位）。
5. **装完立刻删 `install.php`**：
   ```bash
   rm -f /www/wwwroot/你的站点目录/install.php
   ```
   不删也不会被重复安装（有 `storage/install.lock`），但少一个文件少一分风险。
6. **接着做第 4 章**，别跳过。

---

## 4. 装完必须做：Web 服务器安全规则

### 4.1 为什么必须做

安装包里的 `storage/` 存 SQLite 库与备份，`data/` 存种子 CSV。这些都是普通文件，
nginx 不认识"这是数据库"，只会照 URL 把文件内容吐出来。实测过的效果：

```
GET https://站点/storage/kb.sqlite    → 200，4 MB，文件头 "SQLite format 3"
GET https://站点/data/wayfair-qa.csv  → 200，2.5 MB
```

下载回来用任意 SQLite 工具打开就是全站数据。**这跟密码强度、API Key、字段加密都没关系**——
加密保护的是"拿到文件后看不看得懂"，挡不住"文件本身被公开下载"。

### 4.2 宝塔面板（最常见）

**网站 → 设置 → 配置文件**，找到 `server { ... }`，把下面两行粘进去（放在 `server` 大括号内、任意位置，
建议放在 SSL 配置之后），点**保存**，nginx 会自动重载：

```nginx
location ~ ^/(app|data|storage|migrations|tools|examples)/ { deny all; return 404; }
location ~* \.(sqlite|sqlite3|db|db-wal|db-shm|csv|log|lock|bak|zip|sql|md|conf)$ { deny all; return 404; }
```

也可以只写一行引用安装包里的规则文件（以后改规则不用动面板配置）：

```nginx
include /www/wwwroot/你的站点目录/nginx.example.conf;
```

保存后**一定要重载**，然后按 4.4 验证。

### 4.3 命令行 nginx（非宝塔）

在 `server { }` 内同样加那两行，然后：

```bash
nginx -t && nginx -s reload
```

### 4.4 验证（30 秒，必须做）

```bash
# 期望 404；若返回 200 并带 "SQLite format 3" 说明规则没生效
curl -s -o /dev/null -w "%{http_code}\n" https://你的域名/storage/kb.sqlite
curl -s -o /dev/null -w "%{http_code}\n" https://你的域名/data/wayfair-qa.csv
curl -s -o /dev/null -w "%{http_code}\n" https://你的域名/app/db.php
# 期望 200，站点本身没被误伤
curl -s -o /dev/null -w "%{http_code}\n" "https://你的域名/index.php?r=login"
```

后台也有同样的检查：**系统与升级 → 部署安全**，里面有规则原文、一键复制和自检地址。

### 4.5 Apache

安装包自带 `.htaccess`，1.6.1 起已包含等价规则。前提是站点配置里
`AllowOverride All`（宝塔 Apache 默认就是）。验证方法同上。

### 4.6 万一已经被人下载过

按"已泄露"处理，不要抱侥幸：

1. 改管理员密码，以及所有能登录的账号密码；
2. 「我的 API Key」里吊销全部 Key，重新创建（Key 明文是 AES-GCM 加密的，但换掉最省心）；
3. `data/*.csv` 如果不是种子数据了，直接删；
4. 检查后台「最近操作」里有没有异常登录。

问答正文与邮箱在库里是**明文**（要支持全文检索，没做字段加密），泄露即等于内容泄露，这一点要认。

---

## 5. 上线自检表

| 检查 | 方法 | 期望 |
|---|---|---|
| 首页 | 打开 `/` | 302 到登录页或无痕进入首页 |
| 安装向导 | 打开 `/install.php` | 显示"已经安装过了" |
| 数据库 | `curl -r 0-15 https://域名/storage/kb.sqlite` | 404 |
| 种子数据 | 打开 `/data/wayfair-qa.csv` | 404 |
| 源码目录 | 打开 `/app/db.php` | 404（不是 500、不是源码） |
| 接口 | `curl https://域名/api.php?path=/v1/health` | `{"ok":true,...,"version":"x.y.z"}` |
| 接口鉴权 | 不带 Key 请求 `/api.php?path=/v1/entries` | 401 |
| MCP | `curl -X POST https://域名/mcp.php` 带 JSON | 401（无 Key）/ 正常 JSON-RPC（有 Key） |
| 静态资源 | 后台刷新一次，看样式是否正常 | CSS 200，不是 404 |
| 写库 | 后台新建一条问答 | 保存成功，列表可见 |

---

## 6. 报错对照表

按现象查，基本覆盖了实际踩过的坑。

| 现象 | 最可能的原因 | 怎么解决 |
|---|---|---|
| 整站 500 / 白屏 | PHP 版本 < 8.0；缺扩展；`storage/` 不可写；`config.php` 被删 | 看宝塔「网站日志」与 PHP 错误日志（`/www/server/php/8x/var/log/php-fpm.log`）；`php -v` 确认版本 |
| 打开就是 404 | 文件没传全（`index.php` 缺）；站点根目录指错；域名解析没生效 | 确认 `index.php`、`app/`、`assets/` 都在根目录；对比压缩包文件数 |
| 安装页红项：`pdo_sqlite` | 没装扩展 | 宝塔 PHP 设置里装 `pdo_sqlite`，重载 PHP；或改用 MySQL |
| 安装报 `unable to open database file` | `storage/` 不存在或 www 用户不可写 | `mkdir -p storage && chown -R www:www storage && chmod -R 775 storage` |
| 安装报"无法写入 config.php" | 站点根目录不可写 | `chown -R www:www .`；或先手动创建空的 `config.php` 再给它写权限 |
| 登录后立刻退出 / 一直跳登录页 | HTTPS 下用 http 访问（Cookie 带 Secure 发不出去）；带 `www` 与不带 `www` 混用；`session.save_path` 不可写 | 统一用一个域名并强制 HTTPS；检查 PHP 的 session 目录权限 |
| 后台上传更新包报 413 | nginx 默认 `client_max_body_size 1m` | 在 `server{}` 里加 `client_max_body_size 20m;` 并重载 |
| 上传更新包提示"解压失败 / 不是有效 zip" | PHP 缺 `zip` 扩展；或包不完整 | 装 `zip` 扩展；重新下载更新包 |
| 上传后整站 500 | 包版本跨度过大，迁移脚本执行出错 | 看日志里 migrations 报错；先升中间版本；必要时回滚（重传上一版全量包，数据不动） |
| 样式全丢 / 页面错位 | `assets/` 没传全；浏览器强缓存 | 确认 `assets/app.css` 200；强制刷新（资源 URL 已带 mtime 版本号） |
| `/api/v1/search` 404 | 没配伪静态 | 用 `/api.php?path=/v1/search`；或按 4.2 加可选规则 |
| 接口 401 | 没带 `Authorization: Bearer`；Key 被吊销；Key 绑定的分组不是这个库 | 看 `/v1/me`；Key 只能访问它绑定那一个分组 |
| 中文搜不到 | 关键词太碎或含标点 | 用 2 字以上的连续词；试试同义词 |
| 文档在后台更新后出现重复副本 | 更新 `kind=doc` 时没带 `id` | 带 `id` 更新；重复的到列表里删掉 |
| 邮件发不出 | 端口被封（465/25 常见）；授权码错；发件人域名不匹配 | 先试 587 + STARTTLS；后台「邮件」有发送日志与测试发信 |
| `/llms.txt` 404 | nginx 没配 rewrite | 用 `/llms.php`，或加第 4.2 里的可选规则 |
| 时间显示差 8 小时 | 服务器时区与 `config.php` 不一致 | `config.php` 里 `timezone` 默认 `Asia/Shanghai`，改它 |
| 上传报「不支持的文件类型」 | 扩展名没在白名单 | 用 jpg/png/pdf/docx 等；刻意不支持 svg/html/php/js |
| 上传报 413 / 一直失败 | `post_max_size` 小于文件大小 | 调 php.ini 的 `upload_max_filesize` 与 `post_max_size` 后重载 PHP |
| 文件能传但打开报 502 | 所有存储平台都取不到 | 后台「文件存储」逐个「测试连接」；缺副本的点「同步数据」 |
| 换了新平台后老图空白 | 新平台没有历史副本 | 后台点该平台的「同步数据」，等进度到 100% |

---

## 7. 升级

1. **先备份**：`storage/kb.sqlite`（或 `mysqldump`）+ `config.php`。
2. 后台 → **系统与升级** → 选 `update-x.y.z.zip` → 上传。
   包里只有代码与迁移脚本，**不会覆盖** `config.php`、`storage/`、`data/`。
3. 升级完看页面顶部提示的迁移结果；若有失败，日志在 `storage/logs`（若开启）。
4. 刷新一次站点，确认版本号变了（系统与升级页顶部显示当前版本）。
5. 跨多个大版本升级（比如 1.1 → 1.6）请按中间版本逐个升，迁移脚本只保证相邻版本可用。

> 更新包里不含 `install.php`，这是故意的：避免把已经删掉的安装向导又放回去。

---

## 8. 备份与恢复

要备份的只有两样东西：

```bash
# 数据库与备份目录
tar czf kb-backup-$(date +%F).tar.gz storage/ config.php
```

- `config.php` 里存着 `pepper`（API Key 校验用）和邮件密码的加密密钥。**只备份库不备份它**，
  换机器后所有 Key 认证会失效、邮件密码解不开。
- 恢复：把 `storage/` 与 `config.php` 放回原位，权限归 www，直接访问站点即可，无需重装。
- 后台「系统与升级」里的备份只备数据库，`config.php` 仍要自己留一份。

---

## 9. 文件存储（1.7.0 起）

上传的文件默认落在 `storage/uploads/`，也就是**已经在第 4 章被 nginx 规则挡住的目录**，
不用额外加规则。但如果把本地目录改到别处，那目录也必须禁止外部访问。

### 9.1 第一次用之前

1. 后台 → **文件存储**，会看到一个默认的「本地磁盘」平台（已启用、默认）。
2. 上传上限默认 20 MB，同时受 PHP 的 `upload_max_filesize` / `post_max_size` 限制：
   ```ini
   upload_max_filesize = 20M
   post_max_size = 24M
   ```
   改完记得重载 PHP，后台「文件存储」页顶部会显示当前生效值。
3. 目录权限（本地平台）：
   ```bash
   mkdir -p storage/uploads && chown -R www:www storage && chmod -R 775 storage
   ```

**安全前提**：上传目录里绝不能执行 PHP。本包的 nginx/Apache 规则已经把 `storage/` 整个封掉，
所以即使有人传上来一个伪装成图片的脚本也访问不到、更执行不了。若你把目录改到 web 根之外，更安全。

### 9.2 接入对象存储

后台 → 文件存储 → 接入新平台，按平台填：

| 平台 | 必填 | 备注 |
|---|---|---|
| 阿里云 OSS | Endpoint、Bucket、AK、SK | Endpoint 形如 `oss-cn-hangzhou.aliyuncs.com`，不带 bucket |
| 腾讯云 COS | Region、Bucket、SecretId、SecretKey | Bucket 形如 `kb-1250000000`（带 APPID） |
| 七牛云 | Bucket、AK、SK、**绑定域名** | 下载要用绑定域名拼 URL，私有空间会自动签名 |
| 又拍云 | 空间名、操作员、操作员密码 | 私有空间下载带签名 |
| Cloudflare R2 | Account ID、Bucket、AK、SK | 也可填自定义 Endpoint 接自建 MinIO |

保存后是**停用**状态：先点「测试连接」（会真的上传再删除一个探针文件），通过再「启用」。

### 9.3 多副本与灾备补齐（重点）

- **上传时**：文件写到「默认平台 + 所有已启用平台」，各存一份。某个平台失败只记一条告警，不影响上传成功。
- **中途新接平台**：启用后它上面是空的。点该行的「同步数据」——
  后台会把每个缺失的文件从其他平台拉过来再写一份，逐个补齐。**只补不删，可中断续跑**，再点一次接着补。
- **停用平台**：不再接收新文件，历史副本保留，读取时也不会再用它（相当于先挂着）。
- **读取容灾**：下载时按副本顺序依次尝试，某个平台挂了/文件丢了会自动换下一个；
  坏掉的那个副本会被标成「失败」，下次同步会补回来。
- 副本状态在「附件列表 → 副本」列能看到，点标签悬停显示失败原因。

### 9.4 备份口径变了

以前只需要备 `storage/kb.sqlite` + `config.php`。现在**文件在存储平台里**：

- 用了对象存储：文件已在云上，本地不用备；但要记住 `config.php` 的 pepper——
  平台密钥是 AES-GCM 加密存的，pepper 丢了就得重新填一遍 AK/SK（文件本身不受影响）。
- 只用了本地磁盘：`storage/uploads/` 必须一起备份，否则库还在、图没了。
- 建议：至少接两个平台并同步一次，这样单个平台故障或误删都还有一份。

---

## 10. 进阶：把数据库挪出 web 根（最彻底）

nginx 规则是"配对了才安全"。更彻底的做法是让库根本不在网站目录里，
这样即使哪天规则被人误删，也下载不到：

```bash
mkdir -p /www/kbdata && mv /www/wwwroot/站点/storage/kb.sqlite /www/kbdata/
chown -R www:www /www/kbdata
```

然后改 `config.php`：

```php
'sqlite_path' => '/www/kbdata/kb.sqlite',
```

访问一次站点确认正常（写入一条问答），再把旧的 `storage/kb.sqlite` 删掉。
注意：`storage/backups` 里的备份文件仍在站点目录内，第 4 章的规则照样要加。

---

## 11. 包内文件说明

| 文件 | 用途 |
|---|---|
| `install.php` | 安装向导，装完删掉 |
| `config.sample.php` | 配置样例（手动部署时参考） |
| `DEPLOY.md` | 本文件：部署与排错 |
| `nginx.example.conf` | 第 4 章的 nginx 规则，可直接 `include` |
| `README.md` | 功能说明、目录结构、接口概览、开发笔记 |
| `?r=docs` | 站内开发文档（免登录），给接入方看 |
| `llms.php` | `/llms.txt` 内容，给 Agent 读的纯文本索引 |
| `api.php` / `mcp.php` / `openapi.php` | REST / MCP / OpenAPI 三个接入入口 |
| `tools/` | 命令行工具（导入、打包、备份），有 CLI 守卫，不能通过浏览器执行 |
