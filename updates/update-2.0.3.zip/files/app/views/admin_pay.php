<?php
/**
 * 后台：支付设置
 * @var array $conf @var bool $ready @var string $keyMask @var array $methodsAll
 * @var array $orders @var array $events @var array $stat
 */
$route = 'admin_pay';
$stLabel = ['pending' => '待支付', 'paid' => '已支付', 'closed' => '已关闭', 'refunded' => '已退款'];
$kindLabel = ['credits' => '积分包', 'monthly' => '月付'];
?>
<section class="page-head">
  <div>
    <h1 class="page-title">支付设置</h1>
    <p class="page-desc">在线收款走彩虹易支付（V1 接口，MD5 签名）。填好商户号与密钥后打开开关，充值页就会出现「去支付」。</p>
  </div>
  <div class="page-actions">
    <a class="btn" href="<?= e(u('admin_ai')) ?>">套餐与定价</a>
    <a class="btn" href="<?= e(u('recharge')) ?>">前台充值页</a>
  </div>
</section>

<section class="panel">
  <div class="stat-grid">
    <div class="stat">
      <div class="stat-n" style="font-size:18px;color:<?= $ready ? 'var(--ok, #17a673)' : 'var(--err, #d64545)' ?>">
        <?= $ready ? '已开启' : ($conf['enabled'] ? '配置不全' : '未开启') ?>
      </div>
      <div class="stat-l">在线支付</div>
    </div>
    <div class="stat">
      <div class="stat-n">¥<?= number_format((int)$stat['amount_today'] / 100, 2) ?></div>
      <div class="stat-l">今日收款（<?= (int)$stat['paid_today'] ?> 笔）</div>
    </div>
    <div class="stat">
      <div class="stat-n">¥<?= number_format((int)$stat['amount_all'] / 100, 2) ?></div>
      <div class="stat-l">累计在线收款</div>
    </div>
    <div class="stat">
      <div class="stat-n"><?= (int)$stat['pending'] ?></div>
      <div class="stat-l">待支付订单</div>
    </div>
  </div>

  <?php if (!$ready): ?>
    <div class="hint" style="margin-top:14px">
      <p><b>还没生效。</b>需要三样齐全才会生效：商户 ID、商户密钥、至少一个支付方式。
        在易支付商户后台「个人资料 → API 信息」可以拿到商户 ID 和密钥。</p>
    </div>
  <?php endif; ?>
</section>

<section class="panel">
  <h2 class="panel-title">接口配置</h2>
  <form method="post" class="form">
    <?= csrf_field() ?>
    <input type="hidden" name="action" value="save">

    <div class="row-form">
      <label>接口地址
        <input type="text" name="pay_api" value="<?= e((string)$conf['api']) ?>" placeholder="https://pay.cfxcc.cn" required>
      </label>
      <label>商户 ID（pid）
        <input type="text" name="pay_pid" value="<?= e((string)$conf['pid']) ?>" placeholder="1001" autocomplete="off">
      </label>
    </div>

    <div class="row-form">
      <label>商户密钥（KEY）
        <input type="text" name="pay_key" value="" autocomplete="new-password"
               placeholder="<?= $keyMask !== '' ? '已保存：' . e($keyMask) . '（留空表示不修改）' : '在商户后台 API 信息里查看' ?>">
      </label>
      <label>商品名前缀
        <input type="text" name="pay_title_prefix" value="<?= e((string)$conf['title_prefix']) ?>" placeholder="知识库 · ">
      </label>
    </div>
    <div class="field-hint">密钥用 AES-256-GCM 加密存库（密钥来自 <code>config.php</code> 的 pepper）。备份数据库时请一并备份 <code>config.php</code>，否则需要重新填。</div>

    <div style="margin-top:12px">
      <div class="field-hint" style="margin-bottom:6px">开放的支付方式（前台让用户选）</div>
      <?php foreach ($methodsAll as $code => $label): ?>
        <label style="display:inline-flex;flex-direction:row;align-items:center;gap:6px;margin-right:16px;font-weight:400">
          <input type="checkbox" name="methods[]" value="<?= e($code) ?>"
                 <?= in_array($code, $conf['methods'], true) ? 'checked' : '' ?>>
          <?= e($label) ?>
        </label>
      <?php endforeach; ?>
    </div>

    <div style="margin-top:14px;display:grid;gap:8px">
      <label style="display:flex;flex-direction:row;align-items:center;gap:8px;font-weight:400">
        <input type="checkbox" name="pay_use_mapi" value="1" <?= $conf['use_mapi'] ? 'checked' : '' ?>>
        优先用接口支付（拿支付链接直接跳转；关闭则一律走平台收银台页面）
      </label>
      <label style="display:flex;flex-direction:row;align-items:center;gap:8px;font-weight:400">
        <input type="checkbox" name="pay_enabled" value="1" <?= $conf['enabled'] ? 'checked' : '' ?>>
        <b>开启在线支付</b>
      </label>
    </div>

    <div class="ai-bar" style="margin-top:16px">
      <button class="btn primary" type="submit">保存</button>
    </div>
  </form>

  <form method="post" style="margin-top:10px;display:flex;gap:10px;flex-wrap:wrap;align-items:center">
    <?= csrf_field() ?>
    <input type="hidden" name="action" value="test">
    <button class="btn" type="submit">测试连接（查商户信息）</button>
    <span class="tiny muted">会向平台查一次商户余额与状态，不产生订单。</span>
  </form>

  <form method="post" style="margin-top:8px;display:flex;gap:10px;flex-wrap:wrap;align-items:center">
    <?= csrf_field() ?>
    <input type="hidden" name="action" value="refund_probe">
    <button class="btn" type="submit">退款接口自检</button>
    <span class="tiny muted">会读一次商户信息，再用一个<b>不存在的订单号</b>探一次退款接口 —— 不会退任何真钱，只为了看清平台是「没开权限」还是「查不到单」。</span>
  </form>

<?php $rp = $refundProbe ?? null; if (is_array($rp)): ?>
  <?php
  $pr  = (array)($rp['probe'] ?? []);
  $rf  = (array)($rp['refund'] ?? []);
  $rfs = (string)($rf['state'] ?? 'na');
  $rfOk = $rfs === 'allowed';
  $rfTag = $rfs === 'allowed' ? ['ok', '已放行'] : ($rfs === 'denied' ? ['warn', '未开启'] : ['', '未知']);
  ?>
  <section class="panel" style="margin-top:14px">
    <h2 class="panel-title">退款接口自检结果 <span class="tiny muted"><?= e((string)($rp['at'] ?? '')) ?></span></h2>
    <div class="table-wrap">
      <table class="table">
        <tbody>
          <tr>
            <th style="width:110px">探测商户号</th>
            <td>
              <span class="mono"><?= e((string)$conf['pid']) ?></span>
              <span class="tiny muted" style="margin-left:8px">确认你在平台后台开退款开关的，就是这个商户号（自建平台常有多商户，开错号最常见）</span>
            </td>
          </tr>
          <tr>
            <th>商户信息</th>
            <td>
              <span class="tag <?= !empty($pr['ok']) ? 'ok' : 'warn' ?>"><?= !empty($pr['ok']) ? '正常' : '有问题' ?></span>
              <span class="tiny" style="margin-left:6px;white-space:normal"><?= e((string)($pr['message'] ?? '未取到')) ?></span>
            </td>
          </tr>
          <tr>
            <th>退款 API</th>
            <td>
              <span class="tag <?= $rfTag[0] ?>"><?= e($rfTag[1]) ?></span>
              <span class="tiny" style="margin-left:6px;white-space:normal"><?= e((string)($rf['msg'] ?? '')) ?></span>
              <?php if (!empty($rf['probe_no'])): ?>
                <div class="tiny muted mono" style="margin-top:4px">探测单号：<?= e((string)$rf['probe_no']) ?></div>
              <?php endif; ?>
            </td>
          </tr>
        </tbody>
      </table>
    </div>

    <?php if ($rfs === 'denied'): ?>
      <div class="hint" style="margin-top:12px">
        <p><b>平台侧确实没给这个商户号开「订单退款 API」。</b>注意两个开关不是一回事：</p>
        <ul style="margin:6px 0 6px 18px">
          <li><b>开启商户自助退款</b>（你截图里那个）—— 只允许你在商户后台点按钮退款，程序调用不算数；</li>
          <li><b>订单退款 API</b> —— 才允许本系统调用 <code>api.php?act=refund</code> 退款，这是缺的那一个。</li>
        </ul>
        <p>开法：用 <b>商户号 <?= e((string)$conf['pid']) ?></b> 登录 <span class="mono"><?= e((string)$conf['api']) ?></span> 的<b>商户后台</b>（不是平台管理员后台），
           在「个人资料 / API 信息」或「商户设置」里找 <b>订单退款 API</b> 开关，打开后保存。找不到就直接问平台客服：
           「我的商户号 <?= e((string)$conf['pid']) ?> 调用 api.php?act=refund 返回『商户未开启订单退款API接口』，请帮我开退款 API」。</p>
        <p>开通之前想先把账做平：在平台后台手工退款，回下面订单列表点「查单 / 同步」（会自动识别平台已退款）或「线下已退」。</p>
      </div>
    <?php elseif ($rfs === 'allowed'): ?>
      <div class="hint" style="margin-top:12px">
        <p><b>退款接口是通的</b>，平台没有在权限上拦你。之前那笔退款失败是别的原因，重点看这几点：</p>
        <ul style="margin:6px 0 6px 18px">
          <li>那笔订单的<b>平台订单号</b>（<code>trade_no</code>）是否为空或错位 —— 回调没记下来的单可能只有商户单号，退款时要走 <code>out_trade_no</code>；</li>
          <li><b>退款金额</b>：文档写了「少数通道需要与原订单金额一致」，本系统按原额退，但如果那笔单被部分退过就对不上；</li>
          <li>可能是<b>该支付渠道不支持原路退</b>（比如某些小额通道），换别的订单试一笔就知道；</li>
          <li>再去「支付事件日志」（页面底部）看那次 <code>refund</code> 记录的<b>平台原话</b>，比页面提示更准。</li>
        </ul>
      </div>
    <?php else: ?>
      <div class="hint" style="margin-top:12px">
        <p>自检没拿到明确结论。把下面这行发给平台客服，他们一看就知道卡在哪：</p>
        <p class="tiny mono" style="word-break:break-all">商户 <?= e((string)$conf['pid']) ?>，调用 POST <?= e((string)$conf['api']) ?>/api.php?act=refund，返回：<?= e((string)($rf['msg'] ?? '无响应')) ?></p>
      </div>
    <?php endif; ?>
  </section>
<?php endif; ?>

  <div class="hint" style="margin-top:16px">
    <p><b>回调地址（在商户后台不用填，下单时会自动带上）：</b></p>
    <p class="tiny mono" style="word-break:break-all">异步通知：<?= e((string)$conf['notify_url']) ?></p>
    <p class="tiny mono" style="word-break:break-all">同步跳转：<?= e((string)$conf['return_url']) ?></p>
    <p>这两个地址必须是<b>公网能访问的完整域名</b>。如果站点在 CDN / 防火墙后面，要把 <code>/index.php?r=pay_notify</code>
       加进白名单（回调是支付平台服务器直接访问，不经用户浏览器，也不带登录态）。</p>
  </div>
</section>

<?php if (!empty($refunds)): ?>
<section class="panel refund-panel">
  <h2 class="panel-title">退款申请（<?= count($refunds) ?> 条待处理）</h2>
  <p class="tiny muted" style="margin:-4px 0 10px">
    在线单点「同意退款」会直接调用支付平台退款。若报「商户未开启退款API接口」，先做上面的<b>退款接口自检</b>：
    多半是「开启商户自助退款」开了、但「订单退款 API」没开 —— 后者才是允许程序调用的那个。
    开通前请先在平台后台手工退款，再回到下方订单列表点「查单 / 同步」或「线下已退」（会同步回收积分 / 套餐）。
  </p>
  <div class="table-wrap">
    <table class="table">
      <thead>
        <tr><th>申请时间</th><th>用户</th><th>套餐</th><th>金额</th><th>原因</th><th>单号</th><th>处理</th></tr>
      </thead>
      <tbody>
        <?php foreach ($refunds as $r): ?>
          <?php $isEpayR = (string)$r['channel'] === 'epay' && (string)($r['out_trade_no'] ?? '') !== ''; ?>
          <tr>
            <td class="tiny muted"><?= e((string)($r['updated_at'] ?? '')) ?></td>
            <td class="tiny"><?= e((string)($r['username'] ?? ('#' . (int)$r['user_id']))) ?></td>
            <td class="tiny"><?= e((string)($r['plan_name'] ?? '—')) ?></td>
            <td class="tiny mono">¥<?= number_format((int)$r['amount_cents'] / 100, 2) ?></td>
            <td class="tiny" style="max-width:260px;white-space:normal"><?= e((string)($r['refund_reason'] ?? '')) ?></td>
            <td class="tiny mono" style="word-break:break-all"><?= e((string)($r['out_trade_no'] ?? '')) ?></td>
            <td class="tiny" style="min-width:200px">
              <?php
              $confirmMsg = $isEpayR
                  ? '同意后立即调用平台退款 ¥' . number_format((int)$r['amount_cents'] / 100, 2) . '，确认？'
                  : '这单不是在线支付，同意后只会标记已退款并回收权益，钱要你自己退。继续？';
              ?>
              <form method="post" style="display:flex;gap:6px;flex-wrap:wrap;align-items:center"
                    onsubmit="return confirm(<?= e(json_encode($confirmMsg, JSON_UNESCAPED_UNICODE)) ?>);">
                <?= csrf_field() ?>
                <input type="hidden" name="order_id" value="<?= (int)$r['id'] ?>">
                <input type="text" name="note" placeholder="备注（可选）" style="width:110px;font-size:12px;padding:4px 7px;border:1px solid var(--border-strong);border-radius:7px;background:var(--panel-2);color:var(--text)">
                <button class="btn sm primary" type="submit" name="action" value="refund_approve">同意退款</button>
                <button class="btn sm" type="submit" name="action" value="refund_reject" onclick="return confirm('驳回后用户会看到驳回说明，确定？')">驳回</button>
              </form>
              <?php if (!$isEpayR): ?>
                <div class="tiny muted" style="margin-top:4px">非在线支付订单，钱需线下退</div>
              <?php endif; ?>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</section>
<?php endif; ?>

<section class="panel">
  <h2 class="panel-title">订单（最近 60 笔）</h2>
  <?php if (!$orders): ?>
    <p class="muted">还没有在线支付订单。</p>
  <?php else: ?>
    <div class="table-wrap">
      <table class="table">
        <thead>
          <tr><th>时间</th><th>用户</th><th>套餐</th><th>金额</th><th>方式</th><th>状态</th><th>单号 / 流水</th><th>操作</th></tr>
        </thead>
        <tbody>
          <?php foreach ($orders as $o): ?>
            <?php
            $st = (string)$o['status'];
            $isEpay = (string)$o['channel'] === 'epay';
            ?>
            <tr>
              <td class="tiny muted"><?= e((string)$o['created_at']) ?></td>
              <td class="tiny"><?= e((string)($o['username'] ?? ('#' . (int)$o['user_id']))) ?></td>
              <td class="tiny">
                <?= e((string)($o['plan_name'] ?? '—')) ?>
                <span class="tag" style="margin-left:4px"><?= e($kindLabel[(string)$o['kind']] ?? (string)$o['kind']) ?></span>
              </td>
              <td class="tiny mono">¥<?= number_format((int)$o['amount_cents'] / 100, 2) ?></td>
              <td class="tiny"><?= e($isEpay ? pay_method_name((string)($o['pay_method'] ?? '')) : ((string)$o['channel'] === 'manual' ? '手动' : (string)$o['channel'])) ?></td>
              <td class="tiny">
                <span class="tag <?= $st === 'paid' ? 'ok' : ($st === 'refunded' ? 'warn' : '') ?>">
                  <?= e($stLabel[$st] ?? $st) ?>
                </span>
                <?php $rs = (string)($o['refund_state'] ?? 'none'); if ($rs !== '' && $rs !== 'none'): ?>
                  <br><span class="tag <?= $rs === 'pending' ? 'warn' : ($rs === 'done' ? 'ok' : '') ?>"
                        title="<?= e((string)($o['refund_note'] ?? '')) ?>"><?= e(pay_refund_state_label($rs)) ?></span>
                <?php endif; ?>
                <?php if ($st === 'paid' && !empty($o['paid_at'])): ?>
                  <br><span class="tiny muted"><?= e((string)$o['paid_at']) ?></span>
                <?php endif; ?>
              </td>
              <td class="tiny mono" style="word-break:break-all">
                <?= e((string)$o['out_trade_no']) ?>
                <?php if (!empty($o['transaction_id'])): ?>
                  <br><span class="muted"><?= e((string)$o['transaction_id']) ?></span>
                <?php endif; ?>
              </td>
              <td class="tiny">
                <?php if ($isEpay && $st === 'pending'): ?>
                  <form method="post" style="display:inline">
                    <?= csrf_field() ?>
                    <input type="hidden" name="action" value="query">
                    <input type="hidden" name="order_id" value="<?= (int)$o['id'] ?>">
                    <button class="btn sm" type="submit">查单 / 补发货</button>
                  </form>
                  <form method="post" style="display:inline" onsubmit="return confirm('确认关闭这笔待支付订单？');">
                    <?= csrf_field() ?>
                    <input type="hidden" name="action" value="close">
                    <input type="hidden" name="order_id" value="<?= (int)$o['id'] ?>">
                    <button class="btn sm" type="submit">关闭</button>
                  </form>
                <?php elseif ($isEpay && $st === 'paid'): ?>
                  <div style="display:flex;gap:6px;flex-wrap:wrap">
                    <form method="post" style="display:inline"
                          onsubmit="return confirm('确认对订单 <?= e((string)$o['out_trade_no']) ?> 发起退款 ¥<?= number_format((int)$o['amount_cents'] / 100, 2) ?>？退款会调用平台接口，成功后本单标记为已退款，已发积分能扣回就扣回。\n\n若报「商户未开启退款API接口」，说明平台没给商户号开退款权限，请改用右边「线下已退」。');">
                      <?= csrf_field() ?>
                      <input type="hidden" name="action" value="refund">
                      <input type="hidden" name="order_id" value="<?= (int)$o['id'] ?>">
                      <button class="btn sm" type="submit">退款</button>
                    </form>
                    <form method="post" style="display:inline"
                          onsubmit="return confirm('【重要】「线下已退」不会调用支付平台，只是在本站把订单标记为已退款并回收积分/套餐。\n\n请先确认钱已经真正退给用户（在易支付后台手工退款、微信转账等）。\n\n确定要标记吗？');">
                      <?= csrf_field() ?>
                      <input type="hidden" name="action" value="refund_manual">
                      <input type="hidden" name="order_id" value="<?= (int)$o['id'] ?>">
                      <input type="hidden" name="note" value="平台未开放退款接口或已线下退款">
                      <button class="btn sm" type="submit" title="不调接口，只在站内标记为已退款">线下已退</button>
                    </form>
                    <form method="post" style="display:inline">
                      <?= csrf_field() ?>
                      <input type="hidden" name="action" value="query">
                      <input type="hidden" name="order_id" value="<?= (int)$o['id'] ?>">
                      <button class="btn sm" type="submit" title="查平台状态；若平台已退款会自动同步">查单 / 同步</button>
                    </form>
                  </div>
                <?php else: ?>
                  <span class="muted">—</span>
                <?php endif; ?>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php endif; ?>
</section>

<section class="panel">
  <details>
    <summary style="cursor:pointer"><b>支付事件日志</b>（发起 / 回调 / 查单 / 退款，最近 40 条）</summary>
    <div class="table-wrap" style="margin-top:12px">
      <table class="table">
        <thead><tr><th>时间</th><th>类型</th><th>订单号</th><th>签名</th><th>金额</th><th>结果</th><th>来源 IP</th></tr></thead>
        <tbody>
          <?php if (!$events): ?>
            <tr><td colspan="7" class="muted tiny">暂无记录</td></tr>
          <?php endif; ?>
          <?php foreach ($events as $e): ?>
            <tr>
              <td class="tiny muted"><?= e((string)$e['created_at']) ?></td>
              <td class="tiny">
                <?php $k = (string)$e['kind']; ?>
                <span class="tag"><?= e(['start' => '发起', 'notify' => '回调', 'query' => '查单', 'refund' => '退款'][$k] ?? $k) ?></span>
              </td>
              <td class="tiny mono"><?= e((string)$e['out_trade_no']) ?></td>
              <td class="tiny"><?= (int)$e['sign_ok'] === 1 ? '✓' : '<span style="color:var(--err,#d64545)">✗</span>' ?></td>
              <td class="tiny mono"><?= (int)$e['amount_cents'] > 0 ? '¥' . number_format((int)$e['amount_cents'] / 100, 2) : '—' ?></td>
              <td class="tiny"><?= e((string)$e['result']) ?></td>
              <td class="tiny muted mono"><?= e((string)$e['ip']) ?></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
    <div class="field-hint" style="margin-top:8px">
      「签名 ✗」说明回调没通过验签，常见原因是密钥填错、或 notify 地址被改过。这类通知不会发货，可对照结果列排查。
    </div>
  </details>
</section>
