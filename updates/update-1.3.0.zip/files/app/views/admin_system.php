<?php /** @var array $ver @var string $msg @var string $err @var array $history @var string $php @var string $driver */ ?>
<section class="page-head">
  <div>
    <h1 class="page-title">系统与升级</h1>
    <p class="page-desc">当前版本 v<?= e($ver['version'] ?? APP_VERSION) ?>（<?= e($ver['released'] ?? '') ?>）</p>
  </div>
</section>

<?php if ($msg !== ''): ?><div class="flash ok"><?= e($msg) ?></div><?php endif; ?>
<?php if ($err !== ''): ?><div class="flash err"><?= e($err) ?></div><?php endif; ?>

<div class="two-col">
  <section class="panel">
    <h2 class="panel-title">上传更新包</h2>
    <form method="post" action="<?= e(u('admin_system')) ?>" enctype="multipart/form-data" class="form">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="upgrade">
      <label>更新包（.zip）
        <input type="file" name="package" accept=".zip" required>
      </label>
      <div class="hint">
        包内结构：<code>version.json</code> + <code>files/</code> + 可选 <code>migrations/*.php</code>。
        升级前会自动备份数据库（SQLite），<code>config.php</code> 和 <code>storage/</code> 不会被覆盖。
      </div>
      <button class="btn primary" type="submit"
              onclick="return confirm('确定用这个包升级？建议先备份站点文件。')">开始升级</button>
    </form>
  </section>

  <section class="panel">
    <h2 class="panel-title">运行环境</h2>
    <div class="kv">
      <div><span>程序版本</span><b>v<?= e(APP_VERSION) ?></b></div>
      <div><span>PHP</span><b><?= e($php) ?></b></div>
      <div><span>数据库</span><b><?= e($driver === 'sqlite' ? 'SQLite' : 'MySQL') ?></b></div>
      <div><span>时区</span><b><?= e(date_default_timezone_get()) ?></b></div>
      <div><span>zip 扩展</span><b><?= class_exists('ZipArchive') ? '可用' : '缺失（无法在线升级）' ?></b></div>
      <div><span>上传上限</span><b><?= e(ini_get('upload_max_filesize')) ?></b></div>
      <div><span>数据目录</span><b class="mono tiny"><?= e(db_driver() === 'sqlite' ? 'storage/kb.sqlite' : (cfg()['db']['database'] ?? '')) ?></b></div>
    </div>
  </section>
</div>

<section class="panel">
  <h2 class="panel-title">注册与访问</h2>
  <form method="post" action="<?= e(u('admin_system')) ?>" class="form">
    <?= csrf_field() ?>
    <input type="hidden" name="action" value="settings">
    <label class="check-line">
      <input type="checkbox" name="allow_register" value="1" <?= $allowRegister ? 'checked' : '' ?>>
      允许访客自己注册
    </label>
    <div class="hint">
      开启后登录页会出现「注册新账号」。注册成功立即得到一个私有空间，内容只有本人可见（你可以审计）。
      关闭后入口隐藏，直接访问注册地址会返回「未开放」。
    </div>
    <label>同一 IP 每小时最多注册
      <input type="number" name="register_per_hour" min="1" max="100" value="<?= (int)$perHour ?>" class="tiny-input">
    </label>
    <label>站点名称
      <input type="text" name="site_name" value="<?= e(app_name()) ?>" maxlength="60">
    </label>
    <div class="hint">
      当前共 <b><?= (int)$userCount ?></b> 个账号、<b><?= (int)$spaceCount ?></b> 个私有空间。
      全站每小时上限为 <?= register_hourly_cap() ?> 个新账号（按上限的 5 倍自动算，防止被批量注册）。
    </div>
    <div class="form-actions">
      <button class="btn primary" type="submit">保存设置</button>
    </div>
  </form>
</section>

<section class="panel">
  <h2 class="panel-title">升级记录</h2>
  <?php if (!$history): ?>
    <div class="empty">还没有升级记录。</div>
  <?php else: ?>
    <div class="table-wrap">
      <table class="table">
        <thead><tr><th>时间</th><th>动作</th><th>详情</th></tr></thead>
        <tbody>
        <?php foreach ($history as $h): ?>
          <tr>
            <td class="tiny mono"><?= e($h['created_at']) ?></td>
            <td class="tiny"><?= e($h['action']) ?></td>
            <td class="tiny"><?= e($h['detail']) ?></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php endif; ?>
</section>

<section class="panel">
  <h2 class="panel-title">升级操作说明</h2>
  <div class="prose small">
    <p>1. 把新版本的源码目录打成 zip，结构如下：</p>
    <pre><code>update-1.1.0.zip
├── version.json        {"version":"1.1.0","min_version":"1.0.0","notes":"..."}
├── files/              app/  assets/  index.php  api.php ...
└── migrations/         1.1.0.php（可选，每个文件 return function(PDO $pdo){}）</code></pre>
    <p>2. 后台 → 系统与升级 → 选择 zip → 开始升级。系统会：校验版本 → 备份数据库 → 覆盖文件 → 执行迁移 → 写回版本号。</p>
    <p>3. 升级失败时数据库备份在 <code>storage/backups/</code>，把文件恢复回去即可。</p>
  </div>
</section>
