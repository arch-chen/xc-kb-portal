<?php
declare(strict_types=1);

/** 会话认证、登录限速、权限守卫 */

function current_user(): ?array
{
    static $cache = false;
    if ($cache !== false) {
        return $cache;
    }
    $uid = (int)($_SESSION['uid'] ?? 0);
    if ($uid <= 0) {
        return $cache = null;
    }
    $u = one('SELECT * FROM ' . tbl('users') . ' WHERE id = ? AND status = 1', [$uid]);
    if (!$u) {
        unset($_SESSION['uid']);
        return $cache = null;
    }
    return $cache = $u;
}

function is_admin(?array $u = null): bool
{
    $u = $u ?? current_user();
    return $u !== null && ($u['role'] ?? '') === 'admin';
}

function require_login(): array
{
    $u = current_user();
    if (!$u) {
        $_SESSION['after_login'] = $_SERVER['REQUEST_URI'] ?? '';
        redirect(u('login'));
    }
    return $u;
}

function require_admin(): array
{
    $u = require_login();
    if (!is_admin($u)) {
        http_response_code(403);
        exit('403 需要管理员权限');
    }
    return $u;
}

/** 登录失败计数（按会话 + 用户名，简单限速） */
function login_locked_for(): int
{
    $a = $_SESSION['login_fail'] ?? ['n' => 0, 'at' => 0];
    if (($a['n'] ?? 0) < 6) {
        return 0;
    }
    $wait = 60 * min(15, (int)$a['n'] - 5);
    $left = ((int)$a['at'] + $wait) - time();
    return max(0, $left);
}

function login_attempt(string $username, string $password): bool
{
    if (login_locked_for() > 0) {
        return false;
    }
    $u = one('SELECT * FROM ' . tbl('users') . ' WHERE username = ?', [$username]);
    if (!$u || (int)$u['status'] !== 1 || !password_verify($password, $u['password_hash'])) {
        $a = $_SESSION['login_fail'] ?? ['n' => 0, 'at' => 0];
        $_SESSION['login_fail'] = ['n' => (int)$a['n'] + 1, 'at' => time()];
        return false;
    }
    // 顺便升级旧哈希
    if (password_needs_rehash($u['password_hash'], PASSWORD_DEFAULT)) {
        update_row('users', (int)$u['id'], ['password_hash' => password_hash($password, PASSWORD_DEFAULT)]);
    }
    unset($_SESSION['login_fail']);
    session_regenerate_id(true);
    $_SESSION['uid'] = (int)$u['id'];
    update_row('users', (int)$u['id'], ['last_login_at' => now_str()]);
    audit('login', '登录成功');
    return true;
}

function logout(): void
{
    audit('logout');
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $p = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000, $p['path'], $p['domain'], (bool)$p['secure'], (bool)$p['httponly']);
    }
    session_destroy();
}

function create_user(string $username, string $password, string $displayName, string $role = 'user'): int
{
    $id = insert_row('users', [
        'username'      => $username,
        'password_hash' => password_hash($password, PASSWORD_DEFAULT),
        'display_name'  => $displayName,
        'role'          => $role,
        'status'        => 1,
        'created_at'    => now_str(),
    ]);
    return $id;
}

/** API Key 哈希（带 pepper），Web 与 API 共用 */
function key_hash(string $rawKey): string
{
    $pepper = (string)(cfg()['security']['pepper'] ?? '');
    return hash_hmac('sha256', $rawKey, $pepper);
}
