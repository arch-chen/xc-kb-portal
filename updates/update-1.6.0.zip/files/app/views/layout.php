<?php
/** @var string $content */
$u = current_user();
$navGroups = $u ? visible_groups((int)$u['id']) : [];
$activeGroup = get_q('g', '');
$route = get_q('r');
$f = flash();
?>
<!DOCTYPE html>
<html lang="zh-CN" data-theme="system">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e($title ?? app_name()) ?></title>
<link rel="stylesheet" href="<?= e(asset('app.css')) ?>?v=<?= e(asset_ver('app.css')) ?>">
<script>
(function () {
  try {
    var t = localStorage.getItem('kb-theme') || 'system';
    document.documentElement.setAttribute('data-theme', t);
  } catch (e) {}
})();
</script>
</head>
<body>
<div class="shell">
  <aside class="sidebar" id="sidebar">
    <a class="brand" href="<?= e(u()) ?>">
      <span class="brand-mark">知</span>
      <span class="brand-text"><?= e(app_name()) ?></span>
    </a>

    <form class="side-search" action="<?= e(u('search')) ?>" method="get">
      <input type="hidden" name="r" value="search">
      <input type="search" name="q" placeholder="搜索…" value="<?= e(get_q('q')) ?>">
    </form>

    <div class="side-section">
      <div class="side-title">我的分组</div>
      <nav class="side-nav">
        <?php
        // 管理员能看到所有人的私有空间，混在一起太长：自己的（含共享）和用户的各列一栏
        $isAdmin = is_admin($u);
        $sideMine = [];
        $sideUsers = [];
        foreach ($navGroups as $g) {
            $o = (int)$g['owner_id'];
            if ($isAdmin && $o > 0 && $o !== (int)$u['id']) {
                $sideUsers[] = $g;
            } else {
                $sideMine[] = $g;
            }
        }
        ?>
        <?php if (!$sideMine): ?>
          <div class="side-empty">还没有被授权的分组</div>
        <?php endif; ?>
        <?php foreach ($sideMine as $g): ?>
          <a class="side-item <?= (string)$g['slug'] === $activeGroup ? 'active' : '' ?>"
             href="<?= e(u('g', ['slug' => $g['slug']])) ?>">
            <span class="dot"></span>
            <span class="side-item-text"><?= e($g['name']) ?></span>
          </a>
        <?php endforeach; ?>
        <?php if ($sideUsers): ?>
          <div class="side-title">用户的分组 <span class="side-count"><?= count($sideUsers) ?></span></div>
          <?php foreach ($sideUsers as $g): ?>
            <a class="side-item <?= (string)$g['slug'] === $activeGroup ? 'active' : '' ?>"
               href="<?= e(u('g', ['slug' => $g['slug']])) ?>">
              <span class="dot user"></span>
              <span class="side-item-text"><?= e($g['name']) ?></span>
            </a>
          <?php endforeach; ?>
        <?php endif; ?>
      </nav>
    </div>

    <div class="side-foot">
      <a class="side-item" href="<?= e(u('group_new')) ?>"><span class="ico">＋</span>新建分组</a>
      <a class="side-item <?= $route === 'keys' ? 'active' : '' ?>" href="<?= e(u('keys')) ?>"><span class="ico">🔑</span>我的 API Key</a>
      <a class="side-item <?= $route === 'account' ? 'active' : '' ?>" href="<?= e(u('account')) ?>"><span class="ico">👤</span>账户设置</a>
      <?php if (is_admin($u)): ?>
        <a class="side-item" href="<?= e(u('admin')) ?>"><span class="ico">⚙</span>管理后台</a>
      <?php endif; ?>
      <button type="button" class="side-item theme-btn" id="themeBtn">
        <span class="ico" id="themeIco">◐</span><span id="themeLabel">跟随系统</span>
      </button>
      <form method="post" action="<?= e(u('logout')) ?>" class="logout-form">
        <?= csrf_field() ?>
        <button type="submit" class="side-item"><span class="ico">↪</span>退出登录</button>
      </form>
    </div>
  </aside>

  <main class="main">
    <div class="topbar">
      <button class="menu-btn" type="button" id="menuBtn" aria-label="菜单">☰</button>
      <a class="who" href="<?= e(u('account')) ?>" title="账户设置"><?= e($u['display_name'] ?: $u['username']) ?><?= is_admin($u) ? ' · 管理员' : '' ?></a>
    </div>

    <?php if ($f): ?>
      <div class="flash <?= e($f['t']) ?>"><?= e($f['m']) ?></div>
    <?php endif; ?>

    <?= $content ?>
  </main>
</div>
<script src="<?= e(asset('app.js')) ?>?v=<?= e(asset_ver('app.js')) ?>"></script>
</body>
</html>
