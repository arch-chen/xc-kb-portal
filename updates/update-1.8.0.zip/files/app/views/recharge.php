<?php
/** @var array $ent 权益 @var array $wallet 钱包 @var array $plans 套餐 @var array $orders 订单 @var array $logs 流水 */
$route = 'recharge';
?>
<section class="page-head">
  <div>
    <h1 class="page-title">充值 / 兑换</h1>
    <p class="page-desc">积分按次扣：模型越强，单次积分越高。月付套餐额外解锁「自带模型」和更高每日次数。</p>
  </div>
  <div class="page-actions">
    <a class="btn" href="<?= e(u('ai')) ?>">返回 AI 助手</a>
    <a class="btn" href="<?= e(u('ai_models')) ?>">我的模型</a>
  </div>
</section>

<section class="panel">
  <div class="stat-grid">
    <div class="stat">
      <div class="stat-n"><?= (int)$wallet['credits'] ?></div>
      <div class="stat-l">当前积分</div>
    </div>
    <div class="stat">
      <div class="stat-n"><?= (int)$wallet['total_in'] ?></div>
      <div class="stat-l">累计入账</div>
    </div>
    <div class="stat">
      <div class="stat-n"><?= (int)$wallet['total_out'] ?></div>
      <div class="stat-l">累计消耗</div>
    </div>
    <div class="stat">
      <div class="stat-n"><?= $ent['active'] ? '已开通' : '未开通' ?></div>
      <div class="stat-l"><?= $ent['active'] ? e((string)$ent['plan']['name']) : '月付套餐' ?></div>
    </div>
  </div>

  <form method="post" class="form" style="margin-top:16px">
    <?= csrf_field() ?>
    <input type="hidden" name="action" value="redeem">
    <div class="row-form">
      <label>兑换码<input type="text" name="code" placeholder="KBXXXX-XXXX-XXXX" autocomplete="off" required></label>
      <div style="align-self:flex-end"><button class="btn primary" type="submit">立即兑换</button></div>
    </div>
    <div class="field-hint">兑换码由管理员生成。一个码只能用一次（部分批次允许多人各用一次）。</div>
  </form>
</section>

<section class="panel">
  <h2 class="panel-title">套餐</h2>
  <?php if (!$plans): ?>
    <p class="muted">管理员还没有配置套餐。</p>
  <?php else: ?>
    <div class="table-wrap">
      <table class="table">
        <thead><tr><th>名称</th><th>类型</th><th>价格</th><th>内容</th><th>操作</th></tr></thead>
        <tbody>
          <?php foreach ($plans as $p): ?>
            <?php $monthly = (string)$p['kind'] === 'monthly'; ?>
            <tr>
              <td>
                <b><?= e((string)$p['name']) ?></b>
                <?php if ((string)$p['note'] !== ''): ?><br><span class="tiny muted"><?= e((string)$p['note']) ?></span><?php endif; ?>
              </td>
              <td class="tiny"><span class="tag"><?= $monthly ? '月付' : '积分包' ?></span></td>
              <td class="tiny"><?= (int)$p['price_cents'] > 0 ? '¥' . number_format((int)$p['price_cents'] / 100, 2) : '免费' ?></td>
              <td class="tiny">
                <?php if ((int)$p['credits'] > 0): ?>送 <?= (int)$p['credits'] ?> 积分　<?php endif; ?>
                <?php if ($monthly): ?>
                  <?= (int)$p['days'] ?> 天 · 自带模型 <?= (int)$p['custom_slots'] ?> 个 ·
                  每日 <?= (int)$p['daily_calls'] > 0 ? (int)$p['daily_calls'] . ' 次' : '不限次' ?>
                <?php endif; ?>
              </td>
              <td>
                <form method="post">
                  <?= csrf_field() ?>
                  <input type="hidden" name="action" value="buy">
                  <input type="hidden" name="plan_id" value="<?= (int)$p['id'] ?>">
                  <button class="btn sm" type="submit">下单</button>
                </form>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
    <div class="hint" style="margin-top:12px">
      <p><b>关于付款：</b>本期没有在线支付。下单后会生成一个「待支付」订单，你可以
        ① 用兑换码自助充值；② 联系管理员付款，由后台把订单标记为已支付，系统自动发放。
        支付渠道（微信/支付宝）的对接位已经预留，接上后下单即可直接跳转付款。</p>
    </div>
  <?php endif; ?>
</section>

<?php if ($orders): ?>
<section class="panel">
  <h2 class="panel-title">我的订单</h2>
  <div class="table-wrap">
    <table class="table">
      <thead><tr><th>单号</th><th>套餐</th><th>金额</th><th>状态</th><th>时间</th></tr></thead>
      <tbody>
        <?php foreach ($orders as $o): ?>
          <tr>
            <td class="tiny mono"><?= e((string)$o['out_trade_no']) ?></td>
            <td class="tiny"><?= e((string)($o['plan_name'] ?? '—')) ?></td>
            <td class="tiny">¥<?= number_format((int)$o['amount_cents'] / 100, 2) ?></td>
            <td class="tiny">
              <?php
              $st = (string)$o['status'];
              $label = ['pending' => '待支付', 'paid' => '已支付', 'closed' => '已关闭', 'refunded' => '已退款'][$st] ?? $st;
              ?>
              <span class="tag <?= $st === 'paid' ? 'ok' : '' ?>"><?= e($label) ?></span>
            </td>
            <td class="tiny muted"><?= e((string)$o['created_at']) ?></td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</section>
<?php endif; ?>

<?php if ($logs): ?>
<section class="panel">
  <h2 class="panel-title">积分流水</h2>
  <div class="table-wrap">
    <table class="table">
      <thead><tr><th>时间</th><th>变动</th><th>余额</th><th>来源</th><th>说明</th></tr></thead>
      <tbody>
        <?php
        $reasonMap = [
            'ai_call' => 'AI 调用', 'refund' => '失败退回', 'plan_grant' => '套餐赠送',
            'redeem' => '兑换码', 'admin' => '管理员调整', 'pay' => '在线支付',
        ];
        ?>
        <?php foreach ($logs as $l): ?>
          <tr>
            <td class="tiny muted"><?= e((string)$l['created_at']) ?></td>
            <td class="tiny mono" style="color:<?= (int)$l['delta'] > 0 ? 'var(--ok)' : 'var(--text-2)' ?>">
              <?= (int)$l['delta'] > 0 ? '+' : '' ?><?= (int)$l['delta'] ?>
            </td>
            <td class="tiny mono"><?= (int)$l['balance'] ?></td>
            <td class="tiny"><?= e($reasonMap[(string)$l['reason']] ?? (string)$l['reason']) ?></td>
            <td class="tiny muted"><?= e((string)$l['note']) ?></td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</section>
<?php endif; ?>
